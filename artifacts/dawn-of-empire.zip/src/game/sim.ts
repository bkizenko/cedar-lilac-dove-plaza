import {
  AGE_COST,
  AGE_STAT,
  AGES,
  BUILD_ORDER,
  BUILDINGS,
  GATHER,
  HALF,
  TEAM_COLORS,
  TEAM_NAMES,
  TEAM_SHORT,
  TILE,
  UNITS,
} from "./constants";
import type {
  BldType,
  Building,
  Cost,
  GameState,
  HudSnapshot,
  Projectile,
  ResKind,
  ResourceNode,
  Tribe,
  Unit,
  UnitType,
} from "./types";
import { generateWorld, inBounds, sampleHeight, type WorldData } from "./worldgen";

const WALK = 56;

export class Game {
  state: GameState;
  world: WorldData;
  walk: Uint8Array;
  started = false;
  muted = false;
  quality: "low" | "med" | "high" = "high";
  fps = 60;
  onSfx: (name: string) => void = () => {};

  constructor() {
    this.world = generateWorld(0xdae1);
    this.walk = new Uint8Array(WALK * WALK);
    this.state = this.blank();
  }

  blank(): GameState {
    return {
      seed: 0xdae1,
      time: 0,
      age: 0,
      tribes: [],
      units: [],
      buildings: [],
      trees: [],
      stones: [],
      forage: [],
      projectiles: [],
      floaters: [],
      particles: [],
      selBld: null,
      paused: false,
      speed: 1,
      ended: null,
      endReason: "",
      banner: "",
      bannerT: 0,
      placing: null,
      nextId: 1,
      walkDirty: true,
    };
  }

  id() {
    return this.state.nextId++;
  }

  height(x: number, z: number) {
    return sampleHeight(this.world.heights, x, z);
  }

  reset(seed?: number) {
    const s = seed ?? ((Math.random() * 0xffffffff) | 0);
    this.world = generateWorld(s);
    this.state = this.blank();
    this.state.seed = s;
    this.started = true;
    this.state.trees = this.world.trees.map((t) => ({ ...t }));
    this.state.stones = this.world.stones.map((t) => ({ ...t }));
    this.state.forage = this.world.forage.map((t) => ({ ...t }));

    this.state.tribes = TEAM_NAMES.map((name, i) => ({
      id: i,
      name,
      short: TEAM_SHORT[i],
      color: TEAM_COLORS[i],
      food: i === 0 ? 120 : 90,
      wood: i === 0 ? 120 : 80,
      stone: i === 0 ? 50 : 30,
      age: 0,
      aggro: i === 1 ? 0.85 : i === 3 ? 0.35 : 0.5,
      expand: i === 2 ? 0.85 : 0.5,
      tech: i === 3 ? 0.9 : 0.45,
      lastRaid: 80 + i * 20,
      thinkT: 1 + i * 0.4,
      alive: true,
    }));

    for (const camp of this.world.camps) {
      const h = this.height(camp.x, camp.z);
      this.state.buildings.push(this.makeBld("townhall", camp.x, camp.z, camp.team, h));
      this.state.buildings.push(
        this.makeBld("hut", camp.x - 8, camp.z + 6, camp.team, this.height(camp.x - 8, camp.z + 6)),
      );
      this.state.buildings.push(
        this.makeBld("hut", camp.x + 8, camp.z + 5, camp.team, this.height(camp.x + 8, camp.z + 5)),
      );
      if (camp.team === 0) {
        this.state.buildings.push(
          this.makeBld("hut", camp.x - 3, camp.z + 10, camp.team, this.height(camp.x - 3, camp.z + 10)),
        );
      } else {
        this.state.buildings.push(
          this.makeBld("lumber", camp.x + 10, camp.z - 4, camp.team, this.height(camp.x + 10, camp.z - 4)),
        );
      }

      const nWork = camp.team === 0 ? 3 : 2;
      for (let i = 0; i < nWork; i++) {
        const a = (i / nWork) * Math.PI * 2;
        const u = this.spawnUnit("worker", camp.x + Math.cos(a) * 5, camp.z + Math.sin(a) * 5 - 3, camp.team);
        u.job = i === 0 ? "food" : "wood";
        u.order = "idle";
      }
      if (camp.team !== 0) {
        for (let i = 0; i < 2; i++) {
          const a = i * 1.4;
          this.spawnUnit("spearman", camp.x + Math.cos(a) * 6, camp.z + Math.sin(a) * 6, camp.team);
        }
      } else {
        this.spawnUnit("spearman", camp.x + 4, camp.z - 5, camp.team);
      }
    }

    const hx = 0,
      hz = 26;
    for (let i = 0; i < 6; i++) {
      const x = hx - 8 - (i % 3) * 2.4;
      const z = hz - 9 - Math.floor(i / 3) * 2.2;
      this.state.forage.push({
        id: this.id(),
        kind: "forage",
        x,
        z,
        y: this.height(x, z),
        amount: 16,
        scale: 1,
      });
    }
    for (let i = 0; i < 6; i++) {
      const x = hx + 10 + (i % 3) * 2.6;
      const z = hz - 7 - Math.floor(i / 3) * 2.4;
      this.state.trees.push({
        id: this.id(),
        kind: "tree",
        x,
        z,
        y: this.height(x, z),
        amount: 20,
        scale: 1,
      });
    }

    this.rebuildWalk();
    this.banner("A settlement is founded", 2.4);
    this.onSfx("age");
  }

  makeBld(type: BldType, x: number, z: number, team: number, y?: number): Building {
    const d = BUILDINGS[type];
    const hp = d.hp;
    return {
      id: this.id(),
      kind: "building",
      type,
      team,
      x,
      y: y ?? this.height(x, z),
      z,
      w: d.w,
      d: d.d,
      hp,
      maxHp: hp,
      selected: false,
      queue: [],
      rally: null,
      cd: 0,
    };
  }

  spawnUnit(type: UnitType, x: number, z: number, team: number): Unit {
    const d = UNITS[type];
    const tribe = this.state.tribes[team];
    const mul = AGE_STAT[tribe?.age ?? 0];
    const u: Unit = {
      id: this.id(),
      kind: "unit",
      type,
      team,
      x,
      y: this.height(x, z),
      z,
      vx: 0,
      vz: 0,
      facing: 0,
      hp: Math.round(d.hp * mul),
      maxHp: Math.round(d.hp * mul),
      speed: d.speed,
      range: d.range,
      dmg: d.dmg * mul,
      rof: d.rof,
      cd: 0,
      r: d.r,
      selected: false,
      order: "idle",
      tx: x,
      tz: z,
      job: null,
      node: null,
      gatherT: 0,
      carry: 0,
      carryType: null,
      target: null,
      wanderT: 2,
      aggroT: 20 + Math.random() * 20,
    };
    this.state.units.push(u);
    return u;
  }

  tribe(team: number) {
    return this.state.tribes[team];
  }

  popCap(team = 0) {
    let cap = 0;
    for (const b of this.state.buildings) {
      if (b.hp > 0 && b.team === team) cap += BUILDINGS[b.type].pop || 0;
    }
    return cap;
  }

  popNow(team = 0) {
    let n = 0;
    for (const u of this.state.units) if (u.team === team && u.hp > 0) n++;
    return n;
  }

  queued(team = 0) {
    let n = 0;
    for (const b of this.state.buildings) {
      if (b.team === team) n += b.queue.length;
    }
    return n;
  }

  canAfford(team: number, cost: Cost) {
    const t = this.tribe(team);
    if (!t) return false;
    return t.food >= (cost.food || 0) && t.wood >= (cost.wood || 0) && t.stone >= (cost.stone || 0);
  }

  spend(team: number, cost: Cost) {
    const t = this.tribe(team);
    t.food -= cost.food || 0;
    t.wood -= cost.wood || 0;
    t.stone -= cost.stone || 0;
  }

  hasBld(team: number, type: BldType) {
    return this.state.buildings.some((b) => b.team === team && b.type === type && b.hp > 0);
  }

  gatherMul(team: number) {
    let m = 1;
    if (this.hasBld(team, "market")) m *= 0.88;
    return m;
  }

  dmgMul(team: number) {
    return this.hasBld(team, "forge") ? 1.12 : 1;
  }

  banner(text: string, t = 2) {
    this.state.banner = text;
    this.state.bannerT = t;
  }

  addFloater(x: number, y: number, z: number, text: string, color: string) {
    this.state.floaters.push({ x, y, z, text, color, life: 1.4, max: 1.4 });
  }

  addBurst(x: number, y: number, z: number, color: string, n = 8) {
    for (let i = 0; i < n; i++) {
      this.state.particles.push({
        x,
        y,
        z,
        vx: (Math.random() - 0.5) * 4,
        vy: 2 + Math.random() * 3,
        vz: (Math.random() - 0.5) * 4,
        life: 0.5 + Math.random() * 0.4,
        max: 0.8,
        r: 0.08 + Math.random() * 0.08,
        color,
      });
    }
  }

  rebuildWalk() {
    const cell = (HALF * 2) / WALK;
    for (let iz = 0; iz < WALK; iz++) {
      for (let ix = 0; ix < WALK; ix++) {
        const x = -HALF + (ix + 0.5) * cell;
        const z = -HALF + (iz + 0.5) * cell;
        const h = this.height(x, z);
        let ok = h > this.world.waterY + 0.28 && inBounds(x, z, 1.5);
        if (ok) {
          for (const b of this.state.buildings) {
            if (b.hp <= 0) continue;
            if (Math.abs(b.x - x) < b.w * 0.36 && Math.abs(b.z - z) < b.d * 0.36) {
              ok = false;
              break;
            }
          }
        }
        this.walk[iz * WALK + ix] = ok ? 1 : 0;
      }
    }
    this.state.walkDirty = false;
  }

  walkable(x: number, z: number) {
    if (!inBounds(x, z, 1.2)) return false;
    if (this.height(x, z) < this.world.waterY + 0.22) return false;
    const cell = (HALF * 2) / WALK;
    const ix = Math.max(0, Math.min(WALK - 1, Math.floor((x + HALF) / cell)));
    const iz = Math.max(0, Math.min(WALK - 1, Math.floor((z + HALF) / cell)));
    return this.walk[iz * WALK + ix] === 1;
  }

  placementIssue(type: BldType, x: number, z: number, _team = 0): string | null {
    const d = BUILDINGS[type];
    if (!inBounds(x, z, Math.max(d.w, d.d) * 0.5 + 1)) return "Too close to the edge of the valley";
    const steps = 4;
    for (let iz = 0; iz <= steps; iz++) {
      for (let ix = 0; ix <= steps; ix++) {
        const px = x - d.w / 2 + (ix / steps) * d.w;
        const pz = z - d.d / 2 + (iz / steps) * d.d;
        if (this.height(px, pz) < this.world.waterY + 0.28) return "Can't raise that in the water";
      }
    }
    for (const n of this.state.stones) {
      if (n.amount <= 0) continue;
      if (Math.abs(n.x - x) < d.w / 2 + 1.0 && Math.abs(n.z - z) < d.d / 2 + 1.0) {
        return "Too close to a stone outcrop";
      }
    }
    for (const n of this.state.trees) {
      if (n.amount <= 0) continue;
      if (Math.abs(n.x - x) < d.w / 2 + 0.85 && Math.abs(n.z - z) < d.d / 2 + 0.85) {
        return "Too close to the trees — clear a plot first";
      }
    }
    for (const n of this.state.forage) {
      if (n.amount <= 0) continue;
      if (Math.abs(n.x - x) < d.w / 2 + 0.7 && Math.abs(n.z - z) < d.d / 2 + 0.7) {
        return "That's a berry thicket";
      }
    }
    for (const b of this.state.buildings) {
      if (b.hp <= 0) continue;
      if (Math.abs(b.x - x) < (b.w + d.w) * 0.48 && Math.abs(b.z - z) < (b.d + d.d) * 0.48) {
        return "Too close to another building";
      }
    }
    if (type === "quarry") {
      let near = false;
      for (const s of this.state.stones) {
        if (s.amount > 0 && Math.hypot(s.x - x, s.z - z) < 16) {
          near = true;
          break;
        }
      }
      if (!near) return "A quarry must sit near stone";
    }
    return null;
  }

  placementValid(type: BldType, x: number, z: number, team = 0) {
    return this.placementIssue(type, x, z, team) === null;
  }

  findPlaceSpot(type: BldType, x: number, z: number, team = 0) {
    const sx = Math.round(x / TILE) * TILE;
    const sz = Math.round(z / TILE) * TILE;
    if (this.placementValid(type, sx, sz, team)) return { x: sx, z: sz };
    for (let ring = 1; ring <= 5; ring++) {
      const r = ring * TILE;
      for (let i = 0; i < ring * 8; i++) {
        const a = (i / (ring * 8)) * Math.PI * 2;
        const px = Math.round((sx + Math.cos(a) * r) / TILE) * TILE;
        const pz = Math.round((sz + Math.sin(a) * r) / TILE) * TILE;
        if (this.placementValid(type, px, pz, team)) return { x: px, z: pz };
      }
    }
    return null;
  }

  placeBuilding(type: BldType, x: number, z: number, team = 0) {
    if (this.state.ended) return false;
    const d = BUILDINGS[type];
    const tribe = this.tribe(team);
    if (tribe.age < d.age) {
      if (team === 0) this.banner("Requires " + AGES[d.age] + " Age", 1.4);
      return false;
    }
    const cost = { food: d.food, wood: d.wood, stone: d.stone };
    if (!this.canAfford(team, cost)) {
      if (team === 0) {
        this.banner("Not enough resources", 1.3);
        this.onSfx("invalid");
      }
      return false;
    }
    const sx = Math.round(x / TILE) * TILE;
    const sz = Math.round(z / TILE) * TILE;
    const spot = this.findPlaceSpot(type, sx, sz, team);
    if (!spot) {
      if (team === 0) {
        this.banner(this.placementIssue(type, sx, sz, team) || "Can't build there", 1.6);
        this.onSfx("invalid");
      }
      return false;
    }
    this.spend(team, cost);
    const b = this.makeBld(type, spot.x, spot.z, team);
    this.state.buildings.push(b);
    this.state.walkDirty = true;
    this.addBurst(spot.x, b.y + 1, spot.z, "#c4b494", 10);
    if (team === 0) {
      this.addFloater(spot.x, b.y + 3, spot.z, d.name, "#efe4b0");
      this.onSfx("place");
    }
    return true;
  }

  clearSelect() {
    for (const u of this.state.units) u.selected = false;
    for (const b of this.state.buildings) b.selected = false;
    this.state.selBld = null;
  }

  selectedUnits() {
    return this.state.units.filter((u) => u.selected && u.team === 0 && u.hp > 0);
  }

  selectAt(x: number, z: number, additive: boolean) {
    let bestU: Unit | null = null;
    let bd = 2.2;
    for (const u of this.state.units) {
      if (u.hp <= 0) continue;
      const d = Math.hypot(u.x - x, u.z - z);
      if (d < bd) {
        bd = d;
        bestU = u;
      }
    }
    let bestB: Building | null = null;
    let bb = 1e9;
    for (const b of this.state.buildings) {
      if (b.hp <= 0) continue;
      if (Math.abs(b.x - x) < b.w * 0.55 && Math.abs(b.z - z) < b.d * 0.55) {
        const d = Math.hypot(b.x - x, b.z - z);
        if (d < bb) {
          bb = d;
          bestB = b;
        }
      }
    }
    if (bestU && (!bestB || bd < 1.6)) {
      if (!additive) this.clearSelect();
      if (bestU.team === 0) bestU.selected = true;
      else {
        this.clearSelect();
        bestU.selected = true;
      }
      return;
    }
    if (bestB) {
      if (!additive) this.clearSelect();
      bestB.selected = true;
      this.state.selBld = bestB;
      return;
    }
    if (!additive) this.clearSelect();
  }

  selectBox(x0: number, z0: number, x1: number, z1: number) {
    const minx = Math.min(x0, x1),
      maxx = Math.max(x0, x1);
    const minz = Math.min(z0, z1),
      maxz = Math.max(z0, z1);
    this.clearSelect();
    for (const u of this.state.units) {
      if (u.team !== 0 || u.hp <= 0) continue;
      if (u.x >= minx && u.x <= maxx && u.z >= minz && u.z <= maxz) u.selected = true;
    }
  }

  issueMove(x: number, z: number, attackMove = false) {
    const units = this.selectedUnits();
    if (!units.length) {
      if (this.state.selBld && this.state.selBld.team === 0) {
        this.state.selBld.rally = { x, z };
      }
      return;
    }
    const n = units.length;
    const ring = Math.ceil(Math.sqrt(n));
    units.forEach((u, i) => {
      const ox = ((i % ring) - (ring - 1) / 2) * 1.3;
      const oz = (Math.floor(i / ring) - (ring - 1) / 2) * 1.3;
      u.tx = x + ox;
      u.tz = z + oz;
      u.order = attackMove ? "attackmove" : "move";
      u.target = null;
      u.node = null;
    });
    this.onSfx("move");
  }

  issueAttack(target: Unit | Building) {
    const units = this.selectedUnits();
    for (const u of units) {
      u.target = target;
      u.order = "attack";
    }
  }

  enqueueTrain(bld: Building, unitType: UnitType) {
    if (!bld || bld.hp <= 0) return false;
    const d = UNITS[unitType];
    if (d.from !== bld.type) return false;
    const team = bld.team;
    const tribe = this.tribe(team);
    if (tribe.age < d.age) {
      if (team === 0) this.banner("Requires " + AGES[d.age] + " Age", 1.4);
      return false;
    }
    if (this.popNow(team) + this.queued(team) >= this.popCap(team)) {
      if (team === 0) this.banner("Population cap reached", 1.5);
      this.onSfx("invalid");
      return false;
    }
    const cost = { food: d.food, wood: d.wood, stone: d.stone };
    if (!this.canAfford(team, cost)) {
      if (team === 0) this.banner("Not enough resources", 1.3);
      this.onSfx("invalid");
      return false;
    }
    if (bld.queue.length >= 5) return false;
    this.spend(team, cost);
    bld.queue.push({ unit: unitType, t: 0, max: d.train });
    if (team === 0) this.onSfx("click");
    return true;
  }

  trainSelected(unitType: UnitType) {
    const prefer = UNITS[unitType].from;
    let bld =
      this.state.selBld && this.state.selBld.type === prefer && this.state.selBld.hp > 0
        ? this.state.selBld
        : this.state.buildings.find((b) => b.type === prefer && b.team === 0 && b.hp > 0);
    if (bld) this.enqueueTrain(bld, unitType);
  }

  tryAgeUp(team = 0) {
    const tribe = this.tribe(team);
    if (tribe.age >= 5) return;
    const c = AGE_COST[tribe.age + 1];
    if (!c) return;
    if (this.popNow(team) < (c.pop || 0)) {
      if (team === 0) this.banner("Need " + c.pop + " people", 1.6);
      return;
    }
    if (!this.canAfford(team, c)) {
      if (team === 0) this.banner("Not enough resources", 1.4);
      return;
    }
    this.spend(team, c);
    tribe.age++;
    if (team === 0) this.state.age = tribe.age;
    const mul = AGE_STAT[tribe.age] / AGE_STAT[tribe.age - 1];
    for (const u of this.state.units) {
      if (u.team !== team) continue;
      u.hp = Math.round(u.hp * mul);
      u.maxHp = Math.round(u.maxHp * mul);
      u.dmg *= mul;
    }
    if (team === 0) {
      this.onSfx("age");
      this.banner(AGES[tribe.age] + " Age", 2.6);
    }
    this.checkVictory();
  }

  nearestDrop(x: number, z: number, team: number) {
    let best: Building | null = null;
    let bd = 1e12;
    for (const b of this.state.buildings) {
      if (b.hp <= 0 || b.team !== team) continue;
      if (b.type !== "townhall" && b.type !== "warehouse") continue;
      const d = (b.x - x) ** 2 + (b.z - z) ** 2;
      if (d < bd) {
        bd = d;
        best = b;
      }
    }
    return best;
  }

  resKind(node: ResourceNode | Building | null): ResKind | null {
    if (!node) return null;
    if (node.kind === "building") return node.type === "farm" ? "food" : null;
    if (node.kind === "tree") return "wood";
    if (node.kind === "stone") return "stone";
    if (node.kind === "forage" || node.kind === "farm") return "food";
    return null;
  }

  findNode(u: Unit, job: ResKind): ResourceNode | Building | null {
    let best: ResourceNode | Building | null = null;
    let bd = 1e12;
    const consider = (n: ResourceNode | Building, x: number, z: number, extra = 0) => {
      const d = (x - u.x) ** 2 + (z - u.z) ** 2 + extra;
      if (d < bd) {
        bd = d;
        best = n;
      }
    };
    if (job === "food") {
      for (const b of this.state.buildings) {
        if (b.hp > 0 && b.team === u.team && b.type === "farm") consider(b, b.x, b.z, -40);
      }
      for (const n of this.state.forage) if (n.amount > 0) consider(n, n.x, n.z);
    } else if (job === "wood") {
      for (const n of this.state.trees) if (n.amount > 0) consider(n, n.x, n.z);
    } else {
      for (const n of this.state.stones) if (n.amount > 0) consider(n, n.x, n.z);
    }
    return best;
  }

  pickJob(u: Unit): ResKind {
    if (u.job) return u.job;
    const t = this.tribe(u.team);
    const scores: [ResKind, number][] = [
      ["food", 80 - t.food],
      ["wood", 70 - t.wood],
      ["stone", 30 - t.stone],
    ];
    scores.sort((a, b) => b[1] - a[1]);
    for (const [k] of scores) {
      if (this.findNode(u, k)) return k;
    }
    return "food";
  }

  campBonus(u: Unit, job: ResKind) {
    let m = this.gatherMul(u.team);
    const want = job === "wood" ? "lumber" : job === "stone" ? "quarry" : null;
    if (want) {
      for (const b of this.state.buildings) {
        if (b.hp > 0 && b.team === u.team && b.type === want && Math.hypot(b.x - u.x, b.z - u.z) < 16) {
          m *= GATHER[job].campBonus;
          break;
        }
      }
    }
    return m;
  }

  steer(u: Unit, dt: number) {
    const dx = u.tx - u.x;
    const dz = u.tz - u.z;
    const dist = Math.hypot(dx, dz);
    if (dist < 0.45) return true;
    const sp = u.speed * dt;
    const step = Math.min(sp, dist);
    let nx = u.x + (dx / dist) * step;
    let nz = u.z + (dz / dist) * step;
    const stuck = !this.walkable(u.x, u.z);
    if (!stuck && !this.walkable(nx, nz)) {
      if (this.walkable(nx, u.z)) nz = u.z;
      else if (this.walkable(u.x, nz)) nx = u.x;
      else {
        const a = Math.atan2(dx, dz) + (Math.random() - 0.5) * 1.2;
        nx = u.x + Math.sin(a) * step;
        nz = u.z + Math.cos(a) * step;
        if (!this.walkable(nx, nz)) return false;
      }
    }
    u.x = nx;
    u.z = nz;
    u.y = this.height(nx, nz);
    u.facing = Math.atan2(dx, dz);
    return false;
  }

  separate(dt: number) {
    const us = this.state.units;
    for (let i = 0; i < us.length; i++) {
      const a = us[i];
      if (a.hp <= 0) continue;
      for (let j = i + 1; j < us.length; j++) {
        const b = us[j];
        if (b.hp <= 0) continue;
        const dx = a.x - b.x;
        const dz = a.z - b.z;
        const min = a.r + b.r;
        const d2 = dx * dx + dz * dz;
        if (d2 > 0.0001 && d2 < min * min) {
          const d = Math.sqrt(d2);
          const push = ((min - d) / 2) * dt * 8;
          const nx = dx / d;
          const nz = dz / d;
          a.x += nx * push;
          a.z += nz * push;
          b.x -= nx * push;
          b.z -= nz * push;
        }
      }
    }
  }

  workerAI(u: Unit, dt: number) {
    if (u.order === "move") {
      if (this.steer(u, dt)) u.order = "idle";
      return;
    }
    if (u.order === "attack" || u.order === "attackmove") {
      this.combatAI(u, dt);
      return;
    }
    if (u.order === "idle") {
      const job = this.pickJob(u);
      u.job = job;
      const node = this.findNode(u, job);
      if (node) {
        u.node = node;
        u.order = "gather";
        u.tx = node.x;
        u.tz = node.z;
      }
      return;
    }
    if (u.order === "gather") {
      const node = u.node;
      if (!node || ("amount" in node && node.amount <= 0) || ("hp" in node && node.hp <= 0)) {
        u.order = "idle";
        u.node = null;
        return;
      }
      const reach = "w" in node ? Math.max(node.w, node.d) * 0.5 + 0.8 : 1.4;
      if (Math.hypot(u.x - node.x, u.z - node.z) > reach) {
        u.tx = node.x;
        u.tz = node.z;
        this.steer(u, dt);
        return;
      }
      const t = this.resKind(node) || u.job || "food";
      const g = GATHER[t];
      const period = g.period * this.campBonus(u, t);
      u.gatherT += dt;
      u.facing = Math.atan2(node.x - u.x, node.z - u.z);
      if (u.gatherT >= period) {
        u.gatherT = 0;
        u.carry++;
        u.carryType = t;
        if ("amount" in node) {
          node.amount--;
          if (node.amount <= 0) this.addBurst(node.x, u.y + 1, node.z, t === "wood" ? "#3a5a28" : "#888", 6);
        }
        if (u.carry >= g.carry || ("amount" in node && node.amount <= 0)) {
          const drop = this.nearestDrop(u.x, u.z, u.team);
          if (drop) {
            u.order = "return";
            u.tx = drop.x;
            u.tz = drop.z;
          } else u.order = "idle";
        }
      }
      return;
    }
    if (u.order === "return") {
      const drop = this.nearestDrop(u.x, u.z, u.team);
      if (!drop) {
        u.order = "idle";
        return;
      }
      u.tx = drop.x;
      u.tz = drop.z;
      if (Math.hypot(u.x - drop.x, u.z - drop.z) > Math.max(drop.w, drop.d) * 0.55 + 1.4) {
        this.steer(u, dt);
        return;
      }
      if (u.carry > 0 && u.carryType) {
        const tr = this.tribe(u.team);
        tr[u.carryType] += u.carry;
        if (u.team === 0) this.addFloater(drop.x, drop.y + 3, drop.z, "+" + u.carry, "#efe4b0");
        u.carry = 0;
        u.carryType = null;
      }
      const node = this.findNode(u, u.job || this.pickJob(u));
      if (node) {
        u.node = node;
        u.order = "gather";
        u.tx = node.x;
        u.tz = node.z;
      } else u.order = "idle";
    }
  }

  acquireTarget(u: Unit, radius: number) {
    let best: Unit | Building | null = null;
    let bd = radius * radius;
    for (const o of this.state.units) {
      if (o.hp <= 0 || o.team === u.team) continue;
      const d = (o.x - u.x) ** 2 + (o.z - u.z) ** 2;
      if (d < bd) {
        bd = d;
        best = o;
      }
    }
    if (u.team !== 0 || u.order === "attack") {
      for (const b of this.state.buildings) {
        if (b.hp <= 0 || b.team === u.team) continue;
        const d = (b.x - u.x) ** 2 + (b.z - u.z) ** 2;
        if (d < bd) {
          bd = d;
          best = b;
        }
      }
    }
    return best;
  }

  dealDamage(attacker: Unit | Building, target: Unit | Building) {
    if (!target || target.hp <= 0) return;
    const dmg = ("dmg" in attacker ? attacker.dmg : 8) * this.dmgMul(attacker.team);
    target.hp -= dmg;
    this.addBurst(target.x, ("y" in target ? target.y : 0) + 1, target.z, "#c44", 3);
    if (attacker.team === 0 || target.team === 0) this.onSfx("hit");
    if (target.hp <= 0) {
      target.hp = 0;
      this.addBurst(target.x, target.y + 1, target.z, target.team === 0 ? "#888" : "#6a3030", 12);
      this.addFloater(target.x, target.y + 2.4, target.z, target.kind === "building" ? "Destroyed" : "Fallen", "#c44");
      if (target.kind === "building") this.state.walkDirty = true;
      if (target.kind === "unit") {
        for (const u of this.state.units) {
          if (u.target === target) {
            u.target = null;
            if (u.order === "attack") u.order = "idle";
          }
        }
      }
      if (target.team === 0 || attacker.team === 0) this.onSfx("death");
    }
  }

  fireArrow(from: Unit | Building, to: Unit | Building) {
    const p: Projectile = {
      x: from.x,
      y: from.y + 1.4,
      z: from.z,
      tx: to.x,
      ty: to.y + 1,
      tz: to.z,
      target: to,
      speed: 22,
      life: 1.1,
      dmg: ("dmg" in from ? from.dmg : 8) * this.dmgMul(from.team),
      team: from.team,
    };
    this.state.projectiles.push(p);
  }

  combatAI(u: Unit, dt: number) {
    u.cd = Math.max(0, u.cd - dt);
    if (u.order === "move") {
      if (this.steer(u, dt)) u.order = "idle";
      return;
    }
    if (u.order === "attackmove") {
      const t = this.acquireTarget(u, 14);
      if (t) {
        u.target = t;
        u.order = "attack";
      } else {
        if (this.steer(u, dt)) u.order = "idle";
      }
    }
    if (u.order === "idle") {
      const t = this.acquireTarget(u, u.type === "archer" ? 13 : 7);
      if (t) {
        u.target = t;
        u.order = "attack";
      }
      return;
    }
    if (u.order === "attack") {
      const t = u.target;
      if (!t || t.hp <= 0) {
        u.target = null;
        u.order = "idle";
        return;
      }
      u.tx = t.x;
      u.tz = t.z;
      const d = Math.hypot(u.x - t.x, u.z - t.z);
      const reach = u.range + (t.kind === "building" ? Math.max(t.w, t.d) * 0.4 : t.r);
      if (d > reach) this.steer(u, dt);
      else {
        u.facing = Math.atan2(t.x - u.x, t.z - u.z);
        if (u.cd <= 0) {
          u.cd = u.rof;
          if (u.type === "archer") this.fireArrow(u, t);
          else this.dealDamage(u, t);
        }
      }
    }
  }

  barbarianAI(u: Unit, dt: number) {
    u.wanderT -= dt;
    u.aggroT -= dt;
    if (u.order === "attack" && u.target && u.target.hp > 0) {
      this.combatAI(u, dt);
      return;
    }
    const near = this.acquireTarget(u, 12);
    if (near) {
      u.target = near;
      u.order = "attack";
      this.combatAI(u, dt);
      return;
    }
    if (u.order === "attackmove" || u.order === "move") {
      this.combatAI(u, dt);
      return;
    }
    if (u.wanderT <= 0 || Math.hypot(u.x - u.tx, u.z - u.tz) < 0.8) {
      u.wanderT = 2.5 + Math.random() * 4;
      const hall = this.state.buildings.find((b) => b.team === u.team && b.type === "townhall" && b.hp > 0);
      const cx = hall ? hall.x : u.x;
      const cz = hall ? hall.z : u.z;
      const a = Math.random() * Math.PI * 2;
      const r = 4 + Math.random() * 9;
      u.tx = cx + Math.cos(a) * r;
      u.tz = cz + Math.sin(a) * r;
      u.order = "move";
    }
    this.steer(u, dt);
  }

  updateProjectiles(dt: number) {
    const ps = this.state.projectiles;
    for (let i = ps.length - 1; i >= 0; i--) {
      const p = ps[i];
      p.life -= dt;
      const t = p.target;
      const gx = t && t.hp > 0 ? t.x : p.tx;
      const gy = t && t.hp > 0 ? t.y + 1 : p.ty;
      const gz = t && t.hp > 0 ? t.z : p.tz;
      const d = Math.hypot(p.x - gx, p.y - gy, p.z - gz);
      if (d < 0.7 || p.life <= 0) {
        if (t && t.hp > 0) {
          t.hp -= p.dmg;
          this.addBurst(t.x, t.y + 1, t.z, "#c44", 2);
          if (t.hp <= 0) {
            t.hp = 0;
            this.addBurst(t.x, t.y + 1, t.z, "#6a3030", 10);
            if (t.kind === "building") this.state.walkDirty = true;
          }
        }
        ps.splice(i, 1);
        continue;
      }
      const sp = p.speed * dt;
      p.x += ((gx - p.x) / d) * sp;
      p.y += ((gy - p.y) / d) * sp;
      p.z += ((gz - p.z) / d) * sp;
    }
  }

  updateTraining(dt: number) {
    for (const b of this.state.buildings) {
      if (b.hp <= 0 || !b.queue.length) continue;
      const q = b.queue[0];
      q.t += dt;
      if (q.t >= q.max) {
        b.queue.shift();
        if (this.popNow(b.team) >= this.popCap(b.team)) {
          const d = UNITS[q.unit];
          const tr = this.tribe(b.team);
          tr.food += d.food;
          tr.wood += d.wood;
          tr.stone += d.stone;
          continue;
        }
        const a = Math.random() * Math.PI * 2;
        const off = Math.max(b.w, b.d) * 0.6 + 1.2;
        const u = this.spawnUnit(q.unit, b.x + Math.cos(a) * off, b.z + Math.sin(a) * off, b.team);
        if (b.rally) {
          u.tx = b.rally.x;
          u.tz = b.rally.z;
          u.order = "move";
        } else if (q.unit === "worker") u.order = "idle";
        if (b.team === 0) {
          this.onSfx("train");
          this.addFloater(u.x, u.y + 2, u.z, UNITS[q.unit].name, "#c9e8a0");
        }
      }
    }
  }

  updateTowers(dt: number) {
    for (const b of this.state.buildings) {
      if (b.type !== "watchtower" || b.hp <= 0) continue;
      b.cd -= dt;
      if (b.cd > 0) continue;
      let best: Unit | null = null;
      let bd = 16 * 16;
      for (const u of this.state.units) {
        if (u.hp <= 0 || u.team === b.team) continue;
        const d = (u.x - b.x) ** 2 + (u.z - b.z) ** 2;
        if (d < bd) {
          bd = d;
          best = u;
        }
      }
      if (best) {
        b.cd = 1.15;
        this.fireArrow(b, best);
      }
    }
  }

  findOpenSpot(cx: number, cz: number, type: BldType, team: number) {
    const d = BUILDINGS[type];
    for (let r = 6; r < 28; r += 2) {
      for (let i = 0; i < 10; i++) {
        const a = Math.random() * Math.PI * 2;
        const x = cx + Math.cos(a) * r;
        const z = cz + Math.sin(a) * r;
        const sx = Math.round(x / TILE) * TILE;
        const sz = Math.round(z / TILE) * TILE;
        if (this.placementValid(type, sx, sz, team) && this.walkable(sx, sz)) return { x: sx, z: sz };
      }
    }
    void d;
    return null;
  }

  rivalTick(team: number, dt: number) {
    const tr = this.tribe(team);
    if (!tr.alive) return;
    const hall = this.state.buildings.find((b) => b.team === team && b.type === "townhall" && b.hp > 0);
    if (!hall) {
      tr.alive = false;
      if (this.started) this.banner(tr.name + " has fallen", 2.2);
      return;
    }
    tr.thinkT -= dt;
    if (tr.thinkT > 0) return;
    tr.thinkT = 1.6 + Math.random();

    const costScale = 1.25;
    const pop = this.popNow(team);
    const cap = this.popCap(team);

    if (tr.age < 5 && pop >= (AGE_COST[tr.age + 1]?.pop || 0) * 0.9) {
      const c = AGE_COST[tr.age + 1];
      if (c && tr.food > (c.food || 0) * costScale && tr.wood > (c.wood || 0) * costScale && Math.random() < tr.tech + 0.2) {
        this.tryAgeUp(team);
      }
    }

    if (pop + this.queued(team) < cap && tr.food >= 50) {
      const th = hall;
      if (th.queue.length < 2 && Math.random() < 0.55) this.enqueueTrain(th, "worker");
    }

    if (cap - pop < 3 && tr.wood >= 40 && Math.random() < tr.expand) {
      const spot = this.findOpenSpot(hall.x, hall.z, "hut", team);
      if (spot) this.placeBuilding("hut", spot.x, spot.z, team);
    }

    const farms = this.state.buildings.filter((b) => b.team === team && b.type === "farm" && b.hp > 0).length;
    if (farms < 1 + tr.age && tr.wood >= 50 && Math.random() < 0.5) {
      const spot = this.findOpenSpot(hall.x, hall.z, "farm", team);
      if (spot) this.placeBuilding("farm", spot.x, spot.z, team);
    }

    if (tr.age >= 1 && !this.hasBld(team, "barracks") && tr.wood >= 80 && tr.stone >= 40) {
      const spot = this.findOpenSpot(hall.x, hall.z, "barracks", team);
      if (spot) this.placeBuilding("barracks", spot.x, spot.z, team);
    }

    const bar = this.state.buildings.find((b) => b.team === team && b.type === "barracks" && b.hp > 0);
    if (bar && bar.queue.length < 2) {
      const mil = this.state.units.filter((u) => u.team === team && u.type !== "worker" && u.hp > 0).length;
      if (mil < 3 + tr.age * 2) {
        let kind: UnitType = "spearman";
        if (tr.age >= 2 && Math.random() < 0.45) kind = "swordsman";
        else if (tr.age >= 1 && Math.random() < 0.4) kind = "archer";
        if (tr.age >= 4 && this.hasBld(team, "stables") && Math.random() < 0.35) {
          const st = this.state.buildings.find((b) => b.team === team && b.type === "stables" && b.hp > 0);
          if (st) this.enqueueTrain(st, "cavalry");
        } else this.enqueueTrain(bar, kind);
      }
    }

    tr.lastRaid -= dt * 0;
    if (this.state.time > 70 && Math.random() < tr.aggro * 0.18) {
      const mil = this.state.units.filter((u) => u.team === team && u.type !== "worker" && u.hp > 0 && u.order !== "attack");
      if (mil.length >= 2) {
        const targets = this.state.buildings.filter((b) => b.team !== team && b.hp > 0);
        if (targets.length) {
          const t = targets[(Math.random() * targets.length) | 0];
          for (const u of mil.slice(0, 2 + tr.age)) {
            u.tx = t.x;
            u.tz = t.z;
            u.order = "attackmove";
            u.target = t;
          }
        }
      }
    }
  }

  checkVictory() {
    if (this.state.ended) return;
    const th = this.state.buildings.find((b) => b.type === "townhall" && b.team === 0);
    if (!th || th.hp <= 0) {
      this.state.ended = "lose";
      this.state.endReason = "The Town Hall has fallen.";
      this.onSfx("lose");
      return;
    }
    const rivalsAlive = this.state.tribes.filter((t) => t.id !== 0 && t.alive).length;
    const player = this.tribe(0);
    if (player.age >= 5 && this.popNow(0) >= 24) {
      this.state.ended = "win";
      this.state.endReason = "A Renaissance realm of twenty-four souls stands.";
      this.onSfx("win");
      return;
    }
    if (rivalsAlive === 0) {
      this.state.ended = "win";
      this.state.endReason = "The valley's rival tribes have been driven out.";
      this.onSfx("win");
    }
  }

  currentObjective() {
    const count = (type: BldType) =>
      this.state.buildings.filter((b) => b.type === type && b.team === 0 && b.hp > 0).length;
    if (count("farm") < 1) return "Build a Farm  " + count("farm") + "/1";
    if (count("lumber") < 1) return "Build a Lumber Camp  " + count("lumber") + "/1";
    if (this.tribe(0).age < 1) return "Advance to the Bronze Age";
    if (count("barracks") < 1) return "Raise a Barracks  " + count("barracks") + "/1";
    const spears = this.state.units.filter((u) => u.type === "spearman" && u.team === 0 && u.hp > 0).length;
    if (spears < 1) return "Train a Hunter  " + spears + "/1";
    if (this.tribe(0).age < 2) return "Advance to the Iron Age";
    if (this.tribe(0).age < 3) return "Reach the Classical Age";
    if (this.tribe(0).age < 4) return "Reach the Medieval Age";
    if (this.tribe(0).age < 5) return "Found the Renaissance";
    const pop = this.popNow(0);
    if (pop < 24) return "Grow the realm  " + pop + "/24";
    return "The valley is yours";
  }

  clockState() {
    const start = 6 * 3600 + 42 * 60;
    const t = start + this.state.time * 10;
    const day = 1 + Math.floor(t / 86400);
    const tod = ((t % 86400) + 86400) % 86400;
    const h = Math.floor(tod / 3600);
    const m = Math.floor((tod % 3600) / 60);
    const hh = (h < 10 ? "0" : "") + h;
    const mm = (m < 10 ? "0" : "") + m;
    let period = "Night";
    if (h >= 5 && h < 8) period = "Dawn";
    else if (h >= 8 && h < 12) period = "Morning";
    else if (h >= 12 && h < 17) period = "Afternoon";
    else if (h >= 17 && h < 20) period = "Dusk";
    let weather = "Light cloud";
    let temp = 14;
    if (h < 7) {
      weather = "Valley mist";
      temp = 11;
    } else if (h < 10) {
      weather = "Light cloud";
      temp = 14;
    } else if (h < 16) {
      weather = "Clear";
      temp = 18;
    } else if (h < 20) {
      weather = "Golden haze";
      temp = 15;
    } else {
      weather = "Cool night";
      temp = 9;
    }
    return { day, time: hh + ":" + mm, period, weather: weather + " · " + temp + "°C" };
  }

  dayPhase() {
    const start = 6 * 3600 + 42 * 60;
    const t = start + this.state.time * 10;
    const tod = ((t % 86400) + 86400) % 86400;
    return tod / 86400;
  }

  step(dt: number) {
    if (!this.started) return;
    const sdt = this.state.paused || this.state.ended ? 0 : Math.min(dt, 0.05) * this.state.speed;
    if (this.state.walkDirty) this.rebuildWalk();

    if (sdt > 0) {
      this.state.time += sdt;
      for (const u of this.state.units) {
        if (u.hp <= 0) continue;
        if (u.team !== 0 && u.type === "worker") this.workerAI(u, sdt);
        else if (u.team !== 0) this.barbarianAI(u, sdt);
        else if (u.type === "worker") {
          if (u.order === "attack" || u.order === "attackmove") this.combatAI(u, sdt);
          else this.workerAI(u, sdt);
        } else this.combatAI(u, sdt);
      }
      this.separate(sdt);
      this.updateProjectiles(sdt);
      this.updateTraining(sdt);
      this.updateTowers(sdt);
      for (let i = 1; i < this.state.tribes.length; i++) this.rivalTick(i, sdt);

      this.state.units = this.state.units.filter((u) => u.hp > 0);
      this.state.trees = this.state.trees.filter((t) => t.amount > 0);
      this.state.stones = this.state.stones.filter((t) => t.amount > 0);
      this.state.forage = this.state.forage.filter((t) => t.amount > 0);
      this.checkVictory();
    }

    const vdt = Math.min(dt, 0.05);
    for (let i = this.state.particles.length - 1; i >= 0; i--) {
      const p = this.state.particles[i];
      p.life -= vdt;
      p.x += p.vx * vdt;
      p.y += p.vy * vdt;
      p.z += p.vz * vdt;
      p.vy -= 8 * vdt;
      if (p.life <= 0) this.state.particles.splice(i, 1);
    }
    for (let i = this.state.floaters.length - 1; i >= 0; i--) {
      const f = this.state.floaters[i];
      f.life -= vdt;
      f.y += 1.2 * vdt;
      if (f.life <= 0) this.state.floaters.splice(i, 1);
    }
    if (this.state.bannerT > 0) {
      this.state.bannerT -= vdt;
      if (this.state.bannerT <= 0) this.state.banner = "";
    }
  }

  entityAt(x: number, z: number): Unit | Building | null {
    let bestU: Unit | null = null;
    let bd = 2.0;
    for (const u of this.state.units) {
      if (u.hp <= 0) continue;
      const d = Math.hypot(u.x - x, u.z - z);
      if (d < bd) {
        bd = d;
        bestU = u;
      }
    }
    for (const b of this.state.buildings) {
      if (b.hp <= 0) continue;
      if (Math.abs(b.x - x) < b.w * 0.55 && Math.abs(b.z - z) < b.d * 0.55) return bestU && bd < 1.2 ? bestU : b;
    }
    return bestU;
  }

  snapshot(): HudSnapshot {
    const t = this.tribe(0) || {
      food: 0,
      wood: 0,
      stone: 0,
      age: 0,
      name: "",
      color: "",
      alive: true,
      id: 0,
      short: "",
      aggro: 0,
      expand: 0,
      tech: 0,
      lastRaid: 0,
      thinkT: 0,
    };
    const ck = this.clockState();
    const units = this.selectedUnits();
    let selection: HudSnapshot["selection"] = {
      name: "No selection",
      info: "Click a person or building",
      hp: 0,
      maxHp: 1,
      kind: "none",
    };
    if (units.length > 1) {
      selection = {
        name: units.length + " people",
        info: units.map((u) => UNITS[u.type].name).join(", "),
        hp: units.reduce((s, u) => s + u.hp, 0),
        maxHp: units.reduce((s, u) => s + u.maxHp, 0),
        kind: "units",
        type: units[0].type,
        team: 0,
      };
    } else if (units.length === 1) {
      const u = units[0];
      const info =
        u.order === "gather"
          ? "Gathering " + (u.job === "food" ? "berries" : u.job || "")
          : u.order === "return"
            ? "Returning"
            : u.order === "attack"
              ? "Attacking"
              : u.order === "move"
                ? "Moving"
                : u.order === "attackmove"
                  ? "Advance"
                  : "Idle";
      const cap = u.carryType ? GATHER[u.carryType].carry : 8;
      selection = {
        name: UNITS[u.type].name,
        info,
        hp: u.hp,
        maxHp: u.maxHp,
        kind: "unit",
        type: u.type,
        team: u.team,
        carry: u.carry > 0 && u.carryType ? u.carryType + " " + u.carry + "/" + cap : "",
      };
    } else if (this.state.selBld && this.state.selBld.hp > 0) {
      const b = this.state.selBld;
      let info = BUILDINGS[b.type].hint;
      if (b.queue.length) {
        const q = b.queue[0];
        info += " · " + UNITS[q.unit].name + " " + Math.ceil(q.max - q.t) + "s";
        if (b.queue.length > 1) info += " (+" + (b.queue.length - 1) + ")";
      }
      selection = {
        name: BUILDINGS[b.type].name,
        info,
        hp: b.hp,
        maxHp: b.maxHp,
        kind: "building",
        type: b.type,
        team: b.team,
        queue: b.queue.map((q) => q.unit).join(","),
      };
    } else {
      const enemy = this.state.units.find((u) => u.selected && u.team !== 0);
      if (enemy) {
        selection = {
          name: this.tribe(enemy.team).name,
          info: "Hostile · " + UNITS[enemy.type].name,
          hp: enemy.hp,
          maxHp: enemy.maxHp,
          kind: "unit",
          type: enemy.type,
          team: enemy.team,
        };
      }
    }

    const age = t.age;
    const next = AGE_COST[age + 1];
    const trainOptions: HudSnapshot["trainOptions"] = [];
    const hasTH = this.hasBld(0, "townhall");
    const hasBar = this.hasBld(0, "barracks");
    const hasSt = this.hasBld(0, "stables");
    if (hasTH) trainOptions.push({ type: "worker", name: UNITS.worker.name, cost: { food: 50 }, age: 0 });
    if (hasBar) {
      trainOptions.push({ type: "spearman", name: UNITS.spearman.name, cost: { food: 50, wood: 20 }, age: 0 });
      trainOptions.push({ type: "archer", name: UNITS.archer.name, cost: { food: 40, wood: 35 }, age: 1 });
      trainOptions.push({
        type: "swordsman",
        name: UNITS.swordsman.name,
        cost: { food: 70, wood: 20, stone: 20 },
        age: 2,
      });
    }
    if (hasSt) trainOptions.push({ type: "cavalry", name: UNITS.cavalry.name, cost: { food: 80, wood: 40 }, age: 4 });

    const buildOptions = BUILD_ORDER.map((type) => ({
      type,
      name: BUILDINGS[type].name,
      cost: { wood: BUILDINGS[type].wood, stone: BUILDINGS[type].stone, food: BUILDINGS[type].food },
      age: BUILDINGS[type].age,
      hint: BUILDINGS[type].hint,
    }));

    return {
      food: Math.floor(t.food),
      wood: Math.floor(t.wood),
      stone: Math.floor(t.stone),
      pop: this.popNow(0),
      popCap: this.popCap(0),
      age,
      ages: [...AGES],
      time: this.state.time,
      day: ck.day,
      clock: ck.time,
      period: ck.period,
      weather: ck.weather,
      paused: this.state.paused,
      speed: this.state.speed,
      ended: this.state.ended,
      endReason: this.state.endReason,
      objective: this.currentObjective(),
      placing: this.state.placing,
      banner: this.state.bannerT > 0 ? this.state.banner : null,
      selection,
      canAge: !!next && this.canAfford(0, next) && this.popNow(0) >= (next.pop || 0) && age < 5,
      ageCost: next,
      nextAge: age < 5 ? AGES[age + 1] : null,
      tribes: this.state.tribes.map((tr) => ({
        name: tr.short,
        color: tr.color,
        age: tr.age,
        alive: tr.alive,
      })),
      trainOptions,
      buildOptions,
      fps: this.fps,
      started: this.started,
      muted: this.muted,
      quality: this.quality,
    };
  }

  serialize() {
    const s = this.state;
    return {
      seed: s.seed,
      time: s.time,
      tribes: s.tribes,
      units: s.units.map((u) => ({
        ...u,
        node: null,
        target: null,
      })),
      buildings: s.buildings.map((b) => ({ ...b })),
      trees: s.trees,
      stones: s.stones,
      forage: s.forage,
      placing: null,
      nextId: s.nextId,
    };
  }
}

export function dist2(ax: number, az: number, bx: number, bz: number) {
  const dx = ax - bx,
    dz = az - bz;
  return dx * dx + dz * dz;
}
