import type { BldType, Cost, UnitType } from "./types";

export const MAP = 140;
export const HALF = MAP / 2;
export const SEGS = 96;
export const WATER_Y = 0.42;
export const TILE = 2;

export const AGES = ["Stone", "Bronze", "Iron", "Classical", "Medieval", "Renaissance"] as const;

export const AGE_COST: (Cost | null)[] = [
  null,
  { food: 160, wood: 120, stone: 40, pop: 8 },
  { food: 260, wood: 200, stone: 90, pop: 12 },
  { food: 380, wood: 280, stone: 160, pop: 16 },
  { food: 520, wood: 400, stone: 240, pop: 20 },
  { food: 700, wood: 520, stone: 340, pop: 24 },
];

export const AGE_STAT = [1, 1.1, 1.22, 1.35, 1.5, 1.68];

export const BUILDINGS: Record<
  BldType,
  {
    name: string;
    w: number;
    d: number;
    food: number;
    wood: number;
    stone: number;
    pop: number;
    hp: number;
    age: number;
    hint: string;
  }
> = {
  townhall: {
    name: "Town Hall",
    w: 10,
    d: 10,
    food: 0,
    wood: 0,
    stone: 0,
    pop: 8,
    hp: 1100,
    age: 0,
    hint: "Heart of the tribe. Trains gatherers.",
  },
  hut: {
    name: "Hut",
    w: 5.4,
    d: 5.2,
    food: 0,
    wood: 40,
    stone: 0,
    pop: 5,
    hp: 240,
    age: 0,
    hint: "Raises population cap by 5.",
  },
  farm: {
    name: "Farm",
    w: 8.2,
    d: 8.2,
    food: 0,
    wood: 50,
    stone: 0,
    pop: 0,
    hp: 200,
    age: 0,
    hint: "Infinite food plot. Assign gatherers.",
  },
  lumber: {
    name: "Lumber Camp",
    w: 6.2,
    d: 5.8,
    food: 0,
    wood: 45,
    stone: 0,
    pop: 0,
    hp: 220,
    age: 0,
    hint: "Faster woodcutting nearby.",
  },
  quarry: {
    name: "Quarry",
    w: 6.4,
    d: 6,
    food: 0,
    wood: 50,
    stone: 10,
    pop: 0,
    hp: 240,
    age: 1,
    hint: "Must sit near stone. Speeds quarrying.",
  },
  warehouse: {
    name: "Storehouse",
    w: 6.6,
    d: 6,
    food: 0,
    wood: 60,
    stone: 0,
    pop: 0,
    hp: 300,
    age: 1,
    hint: "Extra resource drop-off.",
  },
  barracks: {
    name: "Barracks",
    w: 8.8,
    d: 8.2,
    food: 0,
    wood: 80,
    stone: 40,
    pop: 0,
    hp: 480,
    age: 1,
    hint: "Train hunters, archers, and swordsmen.",
  },
  forge: {
    name: "Forge",
    w: 6.4,
    d: 6,
    food: 0,
    wood: 70,
    stone: 80,
    pop: 0,
    hp: 360,
    age: 2,
    hint: "Tempers blades. +12% military damage.",
  },
  watchtower: {
    name: "Watchtower",
    w: 4.6,
    d: 4.6,
    food: 0,
    wood: 60,
    stone: 50,
    pop: 0,
    hp: 420,
    age: 2,
    hint: "Fires on enemies in range.",
  },
  temple: {
    name: "Temple",
    w: 8.4,
    d: 8,
    food: 40,
    wood: 60,
    stone: 120,
    pop: 8,
    hp: 520,
    age: 3,
    hint: "Faith and order. +8 population.",
  },
  market: {
    name: "Market",
    w: 7.4,
    d: 7,
    food: 0,
    wood: 90,
    stone: 40,
    pop: 0,
    hp: 340,
    age: 3,
    hint: "Traders. Gatherers work 12% faster.",
  },
  keep: {
    name: "Keep",
    w: 9.2,
    d: 9.2,
    food: 0,
    wood: 80,
    stone: 180,
    pop: 6,
    hp: 900,
    age: 4,
    hint: "Stone stronghold. +6 population.",
  },
  stables: {
    name: "Stables",
    w: 8.4,
    d: 8,
    food: 40,
    wood: 100,
    stone: 40,
    pop: 0,
    hp: 400,
    age: 4,
    hint: "Train cavalry.",
  },
  university: {
    name: "University",
    w: 10,
    d: 8.6,
    food: 80,
    wood: 140,
    stone: 160,
    pop: 10,
    hp: 640,
    age: 5,
    hint: "Learning. +10 population.",
  },
};

export const UNITS: Record<
  UnitType,
  {
    name: string;
    hp: number;
    speed: number;
    range: number;
    dmg: number;
    rof: number;
    food: number;
    wood: number;
    stone: number;
    train: number;
    r: number;
    age: number;
    from: BldType;
  }
> = {
  worker: {
    name: "Gatherer",
    hp: 48,
    speed: 5.4,
    range: 1.6,
    dmg: 4,
    rof: 1.2,
    food: 50,
    wood: 0,
    stone: 0,
    train: 7,
    r: 0.55,
    age: 0,
    from: "townhall",
  },
  spearman: {
    name: "Hunter",
    hp: 92,
    speed: 4.8,
    range: 2.2,
    dmg: 12,
    rof: 1.05,
    food: 50,
    wood: 20,
    stone: 0,
    train: 8,
    r: 0.6,
    age: 0,
    from: "barracks",
  },
  archer: {
    name: "Archer",
    hp: 58,
    speed: 5.0,
    range: 12,
    dmg: 9,
    rof: 1.2,
    food: 40,
    wood: 35,
    stone: 0,
    train: 10,
    r: 0.55,
    age: 1,
    from: "barracks",
  },
  swordsman: {
    name: "Swordsman",
    hp: 130,
    speed: 4.5,
    range: 2.0,
    dmg: 16,
    rof: 1.0,
    food: 70,
    wood: 20,
    stone: 20,
    train: 12,
    r: 0.65,
    age: 2,
    from: "barracks",
  },
  cavalry: {
    name: "Rider",
    hp: 150,
    speed: 7.2,
    range: 2.3,
    dmg: 18,
    rof: 1.1,
    food: 80,
    wood: 40,
    stone: 0,
    train: 14,
    r: 0.9,
    age: 4,
    from: "stables",
  },
};

export const GATHER = {
  food: { period: 2.4, carry: 8, campBonus: 0.62 },
  wood: { period: 2.2, carry: 8, campBonus: 0.58 },
  stone: { period: 2.9, carry: 7, campBonus: 0.6 },
};

export const BUILD_ORDER: BldType[] = [
  "hut",
  "farm",
  "lumber",
  "quarry",
  "warehouse",
  "barracks",
  "forge",
  "watchtower",
  "temple",
  "market",
  "keep",
  "stables",
  "university",
];

export const TEAM_COLORS = ["#c4a060", "#8a3030"];
export const TEAM_NAMES = ["Dawnfolk", "Redcliff"];
export const TEAM_SHORT = ["You", "Redcliff"];

export function costOfBuilding(t: BldType): Cost {
  const d = BUILDINGS[t];
  return { food: d.food, wood: d.wood, stone: d.stone };
}

export function costOfUnit(t: UnitType): Cost {
  const d = UNITS[t];
  return { food: d.food, wood: d.wood, stone: d.stone };
}

export const SAVE_KEY = "dawn-of-empire-v2";
export const SAVE_VERSION = 2;
