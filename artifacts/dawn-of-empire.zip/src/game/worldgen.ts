import { HALF, MAP, SEGS, WATER_Y } from "./constants";
import { fbm, mulberry32 } from "./rng";
import type { ResourceNode } from "./types";

export type WorldData = {
  size: number;
  segs: number;
  heights: Float32Array;
  waterY: number;
  trees: ResourceNode[];
  stones: ResourceNode[];
  forage: ResourceNode[];
  camps: { x: number; z: number; team: number }[];
  megaliths: { x: number; z: number; ry: number }[];
};

function idx(ix: number, iz: number) {
  return iz * (SEGS + 1) + ix;
}

export function generateWorld(seed: number): WorldData {
  const rand = mulberry32(seed);
  const n = SEGS + 1;
  const heights = new Float32Array(n * n);

  const riverZ = -8 + rand() * 10;
  const riverA = 0.04 + rand() * 0.03;

  for (let iz = 0; iz < n; iz++) {
    for (let ix = 0; ix < n; ix++) {
      const x = (ix / SEGS) * MAP - HALF;
      const z = (iz / SEGS) * MAP - HALF;
      let h = 1.15 + fbm(x * 0.035, z * 0.035, 5) * 3.4;
      h += fbm(x * 0.09 + 20, z * 0.09, 3) * 0.7;

      const hill1 = 18 - Math.hypot(x + 42, z + 38);
      if (hill1 > 0) h += (hill1 / 18) * (hill1 / 18) * 3.2;
      const hill2 = 16 - Math.hypot(x - 48, z + 22);
      if (hill2 > 0) h += (hill2 / 16) * (hill2 / 16) * 2.6;
      const hill3 = 14 - Math.hypot(x - 18, z - 48);
      if (hill3 > 0) h += (hill3 / 14) * (hill3 / 14) * 2.2;

      const rx = x;
      const rz = z - (riverZ + Math.sin(x * riverA) * 10);
      const rd = Math.abs(rz) - Math.abs(rx) * 0.02;
      const trench = Math.exp(-(rd * rd) / 28);
      h -= trench * 2.1;

      const bowl = Math.hypot(x, z - 22);
      if (bowl < 22) h += (1 - bowl / 22) * 0.35;

      heights[idx(ix, iz)] = Math.max(0.05, h);
    }
  }

  const waterY = WATER_Y;
  let nid = 1;
  const trees: ResourceNode[] = [];
  const stones: ResourceNode[] = [];
  const forage: ResourceNode[] = [];

  const tooClose = (list: ResourceNode[], x: number, z: number, min: number) => {
    for (const n0 of list) {
      const dx = n0.x - x;
      const dz = n0.z - z;
      if (dx * dx + dz * dz < min * min) return true;
    }
    return false;
  };

  for (let i = 0; i < 360; i++) {
    const x = (rand() - 0.5) * (MAP - 8);
    const z = (rand() - 0.5) * (MAP - 8);
    const h = sampleHeight(heights, x, z);
    if (h < waterY + 0.55) continue;
    if (Math.hypot(x, z - 26) < 15) continue;
    if (Math.hypot(x + 48, z + 38) < 12) continue;
    if (tooClose(trees, x, z, 2.8)) continue;
    const dense = fbm(x * 0.07 + 4, z * 0.07, 3);
    if (dense < 0.38 && rand() > 0.28) continue;
    trees.push({
      id: nid++,
      kind: "tree",
      x,
      z,
      y: h,
      amount: 18 + (rand() * 10) | 0,
      scale: 0.95 + rand() * 0.65,
    });
  }

  for (let i = 0; i < 55; i++) {
    const x = (rand() - 0.5) * (MAP - 10);
    const z = (rand() - 0.5) * (MAP - 10);
    const h = sampleHeight(heights, x, z);
    if (h < waterY + 0.9) continue;
    if (tooClose(stones, x, z, 5)) continue;
    if (h < 2.4 && rand() > 0.35) continue;
    stones.push({
      id: nid++,
      kind: "stone",
      x,
      z,
      y: h,
      amount: 22 + (rand() * 12) | 0,
      scale: 0.8 + rand() * 0.5,
    });
  }

  for (let i = 0; i < 70; i++) {
    const x = (rand() - 0.5) * (MAP - 10);
    const z = (rand() - 0.5) * (MAP - 10);
    const h = sampleHeight(heights, x, z);
    if (h < waterY + 0.5 || h > 2.6) continue;
    if (tooClose(forage, x, z, 4)) continue;
    forage.push({
      id: nid++,
      kind: "forage",
      x,
      z,
      y: h,
      amount: 14 + (rand() * 8) | 0,
      scale: 0.9 + rand() * 0.3,
    });
  }

  const camps = [
    { x: 0, z: 26, team: 0 },
    { x: -48, z: -38, team: 1 },
  ];

  const megaliths: { x: number; z: number; ry: number }[] = [];
  for (let i = 0; i < 7; i++) {
    megaliths.push({
      x: (rand() - 0.5) * 100,
      z: (rand() - 0.5) * 100,
      ry: rand() * Math.PI,
    });
  }

  return { size: MAP, segs: SEGS, heights, waterY, trees, stones, forage, camps, megaliths };
}

export function sampleHeight(heights: Float32Array, x: number, z: number) {
  const gx = ((x + HALF) / MAP) * SEGS;
  const gz = ((z + HALF) / MAP) * SEGS;
  const ix = Math.max(0, Math.min(SEGS - 1, Math.floor(gx)));
  const iz = Math.max(0, Math.min(SEGS - 1, Math.floor(gz)));
  const fx = Math.max(0, Math.min(1, gx - ix));
  const fz = Math.max(0, Math.min(1, gz - iz));
  const n = SEGS + 1;
  const a = heights[iz * n + ix];
  const b = heights[iz * n + ix + 1];
  const c = heights[(iz + 1) * n + ix];
  const d = heights[(iz + 1) * n + ix + 1];
  return a * (1 - fx) * (1 - fz) + b * fx * (1 - fz) + c * (1 - fx) * fz + d * fx * fz;
}

export function inBounds(x: number, z: number, pad = 2) {
  return Math.abs(x) < HALF - pad && Math.abs(z) < HALF - pad;
}
