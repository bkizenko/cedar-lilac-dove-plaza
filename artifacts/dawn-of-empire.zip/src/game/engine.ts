import { BUILD_ORDER, BUILDINGS, TILE } from "./constants";
import { Game } from "./sim";
import { GameAudio } from "./audio";
import { saveGame } from "./save";
import type { BldType, HudSnapshot } from "./types";
import { WorldView } from "@/scene/world";

type HudFn = (s: HudSnapshot) => void;

export class Engine {
  game: Game;
  view: WorldView;
  audio: GameAudio;
  canvas: HTMLCanvasElement;
  keys = new Set<string>();
  hud: HudFn;
  running = false;
  last = 0;
  hudAcc = 0;
  saveAcc = 0;
  fpsAcc = 0;
  frames = 0;
  fps = 60;
  drag: { sx: number; sy: number; x: number; y: number } | null = null;
  panDrag: { x: number; y: number } | null = null;
  rotDrag: { x: number; y: number; sx: number; sy: number } | null = null;
  pinch: { d: number; dist: number } | null = null;
  moveMode = false;
  pointer = { x: 0, y: 0 };
  disposed = false;
  ro: ResizeObserver | null = null;

  constructor(canvas: HTMLCanvasElement, hud: HudFn) {
    this.canvas = canvas;
    this.hud = hud;
    this.game = new Game();
    this.view = new WorldView(canvas);
    this.audio = new GameAudio();
    this.game.quality = this.view.quality;
    this.game.onSfx = (n) => this.audio.play(n);
    this.bind();
    this.view.resize();
    this.ro = new ResizeObserver(() => this.view.resize());
    this.ro.observe(canvas.parentElement || canvas);
    this.pushHud();
    this.installProbe();
    (window as unknown as { __engine?: Engine }).__engine = this;
  }

  begin() {
    this.audio.unlock();
    this.game.reset();
    this.view.rebuild(this.game);
    this.view.look.set(0, this.game.height(0, 26) + 0.55, 26);
    this.running = true;
    this.last = performance.now();
    this.view.renderer.setAnimationLoop((t) => this.frame(t));
    this.pushHud();
  }

  restart() {
    this.game.reset();
    this.view.rebuild(this.game);
    this.view.look.set(0, this.game.height(0, 26) + 0.55, 26);
    this.pushHud();
  }

  private bind() {
    const c = this.canvas;
    c.style.touchAction = "none";
    window.addEventListener("resize", this.onResize);
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    window.addEventListener("blur", this.onBlur);
    c.addEventListener("pointerdown", this.onPointerDown);
    c.addEventListener("pointermove", this.onPointerMove);
    c.addEventListener("pointerup", this.onPointerUp);
    c.addEventListener("pointercancel", this.onPointerUp);
    c.addEventListener("wheel", this.onWheel, { passive: false });
    c.addEventListener("contextmenu", (e) => e.preventDefault());
    document.addEventListener("visibilitychange", this.onVis);
  }

  private onResize = () => this.view.resize();
  private onBlur = () => this.keys.clear();
  private onVis = () => {
    if (document.visibilityState === "hidden") saveGame(this.game);
    if (document.visibilityState === "visible" && this.audio.ctx?.state === "suspended") void this.audio.ctx.resume();
  };

  private onKeyDown = (e: KeyboardEvent) => {
    if (e.repeat && (e.code === "Space" || e.code === "KeyP")) return;
    this.keys.add(e.code);
    const block = new Set(["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"]);
    if (block.has(e.code)) e.preventDefault();
    if (!this.game.started) return;
    if (e.code === "Escape") {
      this.game.state.placing = null;
      this.view.setGhost(null, 0, 0, 0, false);
      this.moveMode = false;
    }
    if (e.code === "KeyP" || e.code === "Space") {
      this.game.state.paused = !this.game.state.paused;
    }
    if (e.code === "Equal" || e.code === "NumpadAdd") this.game.state.speed = Math.min(3, this.game.state.speed + 1);
    if (e.code === "Minus" || e.code === "NumpadSubtract") this.game.state.speed = Math.max(1, this.game.state.speed - 1);
    if (e.code === "KeyF") {
      const hall = this.game.state.buildings.find((b) => b.team === 0 && b.type === "townhall");
      if (hall) this.view.look.set(hall.x, hall.y + 0.5, hall.z);
    }
    if (e.code === "KeyM") this.toggleMute();
    const map: Record<string, number> = {
      Digit1: 0,
      Digit2: 1,
      Digit3: 2,
      Digit4: 3,
      Digit5: 4,
      Digit6: 5,
      Digit7: 6,
      Digit8: 7,
    };
    if (map[e.code] !== undefined && !e.metaKey && !e.ctrlKey) {
      const type = BUILD_ORDER[map[e.code]];
      if (type) this.setPlacing(type);
    }
    if (e.code === "KeyH") this.game.banner("WASD pan · RMB rotate · wheel zoom · LMB select · RMB move", 3);
  };

  private onKeyUp = (e: KeyboardEvent) => {
    this.keys.delete(e.code);
  };

  private onWheel = (e: WheelEvent) => {
    e.preventDefault();
    const s = Math.sign(e.deltaY);
    this.view.dist *= s > 0 ? 1.08 : 0.92;
  };

  private canvasXY(e: PointerEvent) {
    const r = this.canvas.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  }

  private onPointerDown = (e: PointerEvent) => {
    this.canvas.setPointerCapture(e.pointerId);
    const p = this.canvasXY(e);
    this.pointer.x = p.x;
    this.pointer.y = p.y;
    if (e.button === 1 || e.buttons === 4) {
      this.panDrag = { x: e.clientX, y: e.clientY };
      return;
    }
    if (e.button === 2) {
      this.rotDrag = { x: e.clientX, y: e.clientY, sx: e.clientX, sy: e.clientY };
      return;
    }
    if (e.button === 0) {
      if (this.game.state.placing) {
        this.drag = null;
        return;
      }
      this.drag = { sx: p.x, sy: p.y, x: p.x, y: p.y };
    }
  };

  private onPointerMove = (e: PointerEvent) => {
    const p = this.canvasXY(e);
    this.pointer.x = p.x;
    this.pointer.y = p.y;
    if (this.panDrag) {
      const dx = e.clientX - this.panDrag.x;
      const dy = e.clientY - this.panDrag.y;
      this.panDrag.x = e.clientX;
      this.panDrag.y = e.clientY;
      const sp = 0.04 * (this.view.dist / 30);
      const fx = -Math.sin(this.view.yaw);
      const fz = -Math.cos(this.view.yaw);
      const rx = Math.cos(this.view.yaw);
      const rz = -Math.sin(this.view.yaw);
      this.view.look.x += -rx * dx * sp + fx * dy * sp;
      this.view.look.z += -rz * dx * sp + fz * dy * sp;
      return;
    }
    if (this.rotDrag) {
      const dx = e.clientX - this.rotDrag.x;
      const dy = e.clientY - this.rotDrag.y;
      this.rotDrag.x = e.clientX;
      this.rotDrag.y = e.clientY;
      this.view.yaw -= dx * 0.005;
      this.view.pitch += dy * 0.004;
      return;
    }
    if (this.drag) {
      this.drag.x = p.x;
      this.drag.y = p.y;
    }
    this.updateGhost();
  };

  private onPointerUp = (e: PointerEvent) => {
    try {
      this.canvas.releasePointerCapture(e.pointerId);
    } catch {
      /* already released */
    }
    const p = this.canvasXY(e);
    this.pointer.x = p.x;
    this.pointer.y = p.y;
    if (this.rotDrag && e.button === 2) {
      const moved = Math.hypot(e.clientX - this.rotDrag.sx, e.clientY - this.rotDrag.sy);
      this.rotDrag = null;
      if (moved < 6) this.rightClick(p.x, p.y);
      return;
    }
    this.rotDrag = null;
    this.panDrag = null;
    if (e.button === 0 && this.game.state.placing) {
      this.leftClick(p.x, p.y, e.shiftKey);
      this.drag = null;
      this.updateGhost();
      this.pushHud();
      return;
    }
    if (this.drag && e.button === 0) {
      const dx = this.drag.x - this.drag.sx;
      const dy = this.drag.y - this.drag.sy;
      if (Math.hypot(dx, dy) > 8) {
        const a = this.view.groundAt(this.drag.sx, this.drag.sy);
        const b = this.view.groundAt(this.drag.x, this.drag.y);
        if (a && b) this.game.selectBox(a.x, a.z, b.x, b.z);
      } else {
        this.leftClick(p.x, p.y, e.shiftKey);
      }
      this.drag = null;
    }
  };

  private leftClick(cx: number, cy: number, additive: boolean) {
    const g = this.view.groundAt(cx, cy);
    if (!g) {
      if (this.game.state.placing) this.game.banner("Aim at the valley floor", 1.2);
      return;
    }
    if (this.game.state.placing) {
      const x = Math.round(g.x / TILE) * TILE;
      const z = Math.round(g.z / TILE) * TILE;
      this.game.placeBuilding(this.game.state.placing, x, z, 0);
      this.updateGhost();
      this.pushHud();
      return;
    }
    if (this.moveMode) {
      this.game.issueMove(g.x, g.z);
      this.moveMode = false;
      return;
    }
    this.game.selectAt(g.x, g.z, additive);
  }

  private rightClick(cx: number, cy: number) {
    const g = this.view.groundAt(cx, cy);
    if (!g) return;
    if (this.game.state.placing) {
      this.game.state.placing = null;
      this.view.setGhost(null, 0, 0, 0, false);
      return;
    }
    const ent = this.game.entityAt(g.x, g.z);
    if (ent && ent.team !== 0) this.game.issueAttack(ent);
    else this.game.issueMove(g.x, g.z);
  }

  private updateGhost() {
    const type = this.game.state.placing;
    if (!type) {
      this.view.setGhost(null, 0, 0, 0, false);
      return;
    }
    const g = this.view.groundAt(this.pointer.x, this.pointer.y);
    if (!g) return;
    const x = Math.round(g.x / TILE) * TILE;
    const z = Math.round(g.z / TILE) * TILE;
    const ok =
      this.game.placementValid(type, x, z, 0) &&
      this.game.canAfford(0, {
        food: BUILDINGS[type].food,
        wood: BUILDINGS[type].wood,
        stone: BUILDINGS[type].stone,
      });
    this.view.setGhost(type, x, z, this.game.height(x, z), ok);
  }

  setPlacing(type: BldType | null) {
    if (type && this.game.state.ended) return;
    this.game.state.placing = this.game.state.placing === type ? null : type;
    if (this.game.state.placing) {
      const d = BUILDINGS[this.game.state.placing];
      this.game.banner("Click the valley to raise a " + d.name + "  ·  Esc cancel", 2.4);
    }
    this.updateGhost();
    this.audio.play("click");
    this.pushHud();
  }

  train(type: Parameters<Game["trainSelected"]>[0]) {
    this.game.trainSelected(type);
  }

  ageUp() {
    this.game.tryAgeUp(0);
  }

  setPaused(p: boolean) {
    this.game.state.paused = p;
  }

  setSpeed(s: number) {
    this.game.state.speed = s;
  }

  toggleMute() {
    this.game.muted = !this.game.muted;
    this.audio.setMuted(this.game.muted);
  }

  setQuality(q: "low" | "med" | "high") {
    this.game.quality = q;
    this.view.applyQuality(q);
  }

  focusMinimap(nx: number, nz: number) {
    this.view.look.x = nx;
    this.view.look.z = nz;
    this.view.look.y = this.game.height(nx, nz) + 0.4;
  }

  private frame = (t: number) => {
    if (this.disposed) return;
    const dt = this.last ? Math.min((t - this.last) / 1000, 0.1) : 0.016;
    this.last = t;
    this.frames++;
    this.fpsAcc += dt;
    if (this.fpsAcc >= 0.4) {
      this.fps = this.frames / this.fpsAcc;
      this.game.fps = Math.round(this.fps);
      this.frames = 0;
      this.fpsAcc = 0;
    }

    this.view.pan.x = 0;
    this.view.pan.z = 0;
    if (this.keys.has("KeyW") || this.keys.has("ArrowUp")) this.view.pan.z += 1;
    if (this.keys.has("KeyS") || this.keys.has("ArrowDown")) this.view.pan.z -= 1;
    if (this.keys.has("KeyA") || this.keys.has("ArrowLeft")) this.view.pan.x -= 1;
    if (this.keys.has("KeyD") || this.keys.has("ArrowRight")) this.view.pan.x += 1;
    if (this.keys.has("KeyQ")) this.view.yaw += 0.9 * dt;
    if (this.keys.has("KeyE")) this.view.yaw -= 0.9 * dt;

    this.game.step(dt);
    this.updateGhost();
    this.view.updateCamera(dt);
    this.view.sync(this.game, dt);
    this.view.render();

    this.hudAcc += dt;
    if (this.hudAcc > 0.12) {
      this.hudAcc = 0;
      this.pushHud();
    }
    this.saveAcc += dt;
    if (this.saveAcc > 18) {
      this.saveAcc = 0;
      saveGame(this.game);
    }
  };

  pushHud() {
    this.hud(this.game.snapshot());
  }

  getDragRect() {
    if (!this.drag) return null;
    if (Math.hypot(this.drag.x - this.drag.sx, this.drag.y - this.drag.sy) < 8) return null;
    return this.drag;
  }

  private installProbe() {
    window.__controlsTest = {
      getYaw: () => this.view.yaw,
      getSpeed: () => Math.hypot(this.view.pan.x, this.view.pan.z) + (this.running ? this.view.dist * 0.001 : 0),
      setKeys: (codes: string[]) => {
        this.keys.clear();
        for (const c of codes) this.keys.add(c);
      },
    };
    (window as unknown as { __engine?: Engine }).__engine = this;
  }

  dispose() {
    this.disposed = true;
    this.running = false;
    this.view.renderer.setAnimationLoop(null);
    this.ro?.disconnect();
    window.removeEventListener("resize", this.onResize);
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    window.removeEventListener("blur", this.onBlur);
    document.removeEventListener("visibilitychange", this.onVis);
    this.canvas.removeEventListener("pointerdown", this.onPointerDown);
    this.canvas.removeEventListener("pointermove", this.onPointerMove);
    this.canvas.removeEventListener("pointerup", this.onPointerUp);
    this.view.dispose();
    this.audio.dispose();
  }
}

declare global {
  interface Window {
    __controlsTest?: {
      getYaw: () => number;
      getSpeed: () => number;
      setKeys?: (codes: string[]) => void;
    };
  }
}
