export type UnitType = "worker" | "spearman" | "archer" | "swordsman" | "cavalry";

export type BldType =
  | "townhall"
  | "hut"
  | "farm"
  | "lumber"
  | "quarry"
  | "warehouse"
  | "barracks"
  | "forge"
  | "watchtower"
  | "temple"
  | "market"
  | "keep"
  | "stables"
  | "university";

export type ResKind = "food" | "wood" | "stone";
export type Order = "idle" | "move" | "gather" | "return" | "attack" | "attackmove";

export type Cost = { food?: number; wood?: number; stone?: number; pop?: number };

export type Unit = {
  id: number;
  kind: "unit";
  type: UnitType;
  team: number;
  x: number;
  y: number;
  z: number;
  vx: number;
  vz: number;
  facing: number;
  hp: number;
  maxHp: number;
  speed: number;
  range: number;
  dmg: number;
  rof: number;
  cd: number;
  r: number;
  selected: boolean;
  order: Order;
  tx: number;
  tz: number;
  job: ResKind | null;
  node: ResourceNode | Building | null;
  gatherT: number;
  carry: number;
  carryType: ResKind | null;
  target: Unit | Building | null;
  wanderT: number;
  aggroT: number;
};

export type QueueItem = { unit: UnitType; t: number; max: number };

export type Building = {
  id: number;
  kind: "building";
  type: BldType;
  team: number;
  x: number;
  y: number;
  z: number;
  w: number;
  d: number;
  hp: number;
  maxHp: number;
  selected: boolean;
  queue: QueueItem[];
  rally: { x: number; z: number } | null;
  cd: number;
};

export type ResourceNode = {
  id: number;
  kind: "tree" | "stone" | "forage" | "farm";
  x: number;
  z: number;
  y: number;
  amount: number;
  scale: number;
};

export type Floater = {
  x: number;
  y: number;
  z: number;
  text: string;
  color: string;
  life: number;
  max: number;
};

export type Projectile = {
  x: number;
  y: number;
  z: number;
  tx: number;
  ty: number;
  tz: number;
  target: Unit | Building | null;
  speed: number;
  life: number;
  dmg: number;
  team: number;
};

export type Tribe = {
  id: number;
  name: string;
  short: string;
  color: string;
  food: number;
  wood: number;
  stone: number;
  age: number;
  aggro: number;
  expand: number;
  tech: number;
  lastRaid: number;
  thinkT: number;
  alive: boolean;
};

export type Particle = {
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  life: number;
  max: number;
  r: number;
  color: string;
};

export type GameState = {
  seed: number;
  time: number;
  age: number;
  tribes: Tribe[];
  units: Unit[];
  buildings: Building[];
  trees: ResourceNode[];
  stones: ResourceNode[];
  forage: ResourceNode[];
  projectiles: Projectile[];
  floaters: Floater[];
  particles: Particle[];
  selBld: Building | null;
  paused: boolean;
  speed: number;
  ended: null | "win" | "lose";
  endReason: string;
  banner: string;
  bannerT: number;
  placing: BldType | null;
  nextId: number;
  walkDirty: boolean;
};

export type HudSelection = {
  name: string;
  info: string;
  hp: number;
  maxHp: number;
  kind: "none" | "unit" | "units" | "building";
  type?: string;
  team?: number;
  queue?: string;
  carry?: string;
};

export type HudSnapshot = {
  food: number;
  wood: number;
  stone: number;
  pop: number;
  popCap: number;
  age: number;
  ages: string[];
  time: number;
  day: number;
  clock: string;
  period: string;
  weather: string;
  paused: boolean;
  speed: number;
  ended: null | "win" | "lose";
  endReason: string;
  objective: string;
  placing: BldType | null;
  banner: string | null;
  selection: HudSelection;
  canAge: boolean;
  ageCost: Cost | null;
  nextAge: string | null;
  tribes: { name: string; color: string; age: number; alive: boolean }[];
  trainOptions: { type: UnitType; name: string; cost: Cost; age: number }[];
  buildOptions: { type: BldType; name: string; cost: Cost; age: number; hint: string }[];
  fps: number;
  started: boolean;
  muted: boolean;
  quality: "low" | "med" | "high";
};
