export class GameAudio {
  ctx: AudioContext | null = null;
  master: GainNode | null = null;
  sfx: GainNode | null = null;
  music: GainNode | null = null;
  muted = false;
  unlocked = false;
  drones: OscillatorNode[] = [];
  private scoreTimer: number | null = null;
  private scoreStart = 0;
  private lastBar = -1;
  private noise: AudioBuffer | null = null;

  unlock() {
    if (this.unlocked) {
      if (this.ctx?.state === "suspended") void this.ctx.resume();
      return;
    }
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    this.ctx = new AC({ latencyHint: "interactive" });
    this.master = this.ctx.createGain();
    this.sfx = this.ctx.createGain();
    this.music = this.ctx.createGain();
    this.sfx.gain.value = 0.7;
    this.music.gain.value = 0.4;
    this.master.gain.value = 0.55;
    this.sfx.connect(this.master);
    this.music.connect(this.master);
    this.master.connect(this.ctx.destination);
    this.noise = this.makeNoise(this.ctx);
    void this.ctx.resume();
    this.unlocked = true;
    this.startScore();
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible" && this.ctx?.state === "suspended") void this.ctx.resume();
    });
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.master && this.ctx) {
      this.master.gain.setTargetAtTime(m ? 0 : 0.55, this.ctx.currentTime, 0.04);
    }
  }

  private makeNoise(ctx: AudioContext) {
    const n = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
    const d = n.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    return n;
  }

  tone(freq: number, dur: number, type: OscillatorType = "triangle", vol = 0.08, detune = 0) {
    if (!this.ctx || !this.sfx || this.muted) return;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = type;
    o.frequency.value = freq;
    o.detune.value = detune;
    g.gain.setValueAtTime(vol, this.ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.0008, this.ctx.currentTime + dur);
    o.connect(g);
    g.connect(this.sfx);
    o.start();
    o.stop(this.ctx.currentTime + dur);
  }

  play(name: string) {
    const r = 0.92 + Math.random() * 0.16;
    switch (name) {
      case "click":
        this.tone(520 * r, 0.06, "square", 0.04);
        break;
      case "place":
        this.tone(180, 0.12, "triangle", 0.07);
        this.tone(320, 0.18, "sine", 0.04);
        break;
      case "move":
        this.tone(240 * r, 0.07, "sine", 0.03);
        break;
      case "hit":
        this.tone(110 * r, 0.08, "sawtooth", 0.05);
        break;
      case "death":
        this.tone(90, 0.25, "triangle", 0.06);
        this.tone(70, 0.3, "sine", 0.05);
        break;
      case "train":
        this.tone(400, 0.1, "triangle", 0.05);
        this.tone(600, 0.16, "sine", 0.03);
        break;
      case "age":
        this.tone(220, 0.35, "triangle", 0.07);
        this.tone(330, 0.45, "sine", 0.05);
        this.tone(440, 0.55, "sine", 0.04);
        break;
      case "win":
        this.tone(262, 0.4, "triangle", 0.07);
        this.tone(330, 0.5, "sine", 0.05);
        this.tone(392, 0.7, "sine", 0.05);
        break;
      case "lose":
        this.tone(196, 0.5, "triangle", 0.06);
        this.tone(147, 0.7, "sine", 0.05);
        break;
      case "invalid":
        this.tone(140, 0.1, "square", 0.04);
        break;
      default:
        this.tone(300, 0.05, "sine", 0.03);
    }
  }

  private hz(semi: number) {
    return 146.83 * Math.pow(2, semi / 12);
  }

  private pluck(time: number, semi: number, dur = 0.55, vol = 0.055) {
    if (!this.ctx || !this.music) return;
    const o = this.ctx.createOscillator();
    const o2 = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    const f = this.ctx.createBiquadFilter();
    o.type = "triangle";
    o2.type = "sine";
    o.frequency.value = this.hz(semi);
    o2.frequency.value = this.hz(semi) * 2;
    f.type = "lowpass";
    f.frequency.setValueAtTime(2200, time);
    f.frequency.exponentialRampToValueAtTime(480, time + dur);
    g.gain.setValueAtTime(0.0001, time);
    g.gain.exponentialRampToValueAtTime(vol, time + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, time + dur);
    o.connect(f);
    o2.connect(f);
    f.connect(g);
    g.connect(this.music);
    o.start(time);
    o2.start(time);
    o.stop(time + dur + 0.05);
    o2.stop(time + dur + 0.05);
  }

  private flute(time: number, semi: number, dur = 0.85, vol = 0.03) {
    if (!this.ctx || !this.music) return;
    const o = this.ctx.createOscillator();
    const lfo = this.ctx.createOscillator();
    const lfoG = this.ctx.createGain();
    const g = this.ctx.createGain();
    o.type = "sine";
    o.frequency.value = this.hz(semi + 12);
    lfo.type = "sine";
    lfo.frequency.value = 5.2;
    lfoG.gain.value = 7;
    lfo.connect(lfoG);
    lfoG.connect(o.detune);
    g.gain.setValueAtTime(0.0001, time);
    g.gain.linearRampToValueAtTime(vol, time + 0.08);
    g.gain.linearRampToValueAtTime(vol * 0.7, time + dur * 0.6);
    g.gain.exponentialRampToValueAtTime(0.0001, time + dur);
    o.connect(g);
    g.connect(this.music);
    o.start(time);
    lfo.start(time);
    o.stop(time + dur + 0.05);
    lfo.stop(time + dur + 0.05);
  }

  private drum(time: number) {
    if (!this.ctx || !this.music) return;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = "sine";
    o.frequency.setValueAtTime(90, time);
    o.frequency.exponentialRampToValueAtTime(42, time + 0.18);
    g.gain.setValueAtTime(0.05, time);
    g.gain.exponentialRampToValueAtTime(0.0001, time + 0.22);
    o.connect(g);
    g.connect(this.music);
    o.start(time);
    o.stop(time + 0.25);
  }

  private startPads() {
    if (!this.ctx || !this.music) return;
    const parts: { f: number; type: OscillatorType; vol: number }[] = [
      { f: 73.42, type: "sine", vol: 0.055 },
      { f: 110, type: "sine", vol: 0.036 },
      { f: 146.83, type: "triangle", vol: 0.022 },
      { f: 220, type: "sine", vol: 0.014 },
      { f: 174.61, type: "sine", vol: 0.01 },
    ];
    for (const p of parts) {
      const o = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      const filt = this.ctx.createBiquadFilter();
      o.type = p.type;
      o.frequency.value = p.f;
      filt.type = "lowpass";
      filt.frequency.value = 640;
      g.gain.value = p.vol;
      o.connect(filt);
      filt.connect(g);
      g.connect(this.music);
      o.start();
      this.drones.push(o);
    }
    if (this.noise) {
      const src = this.ctx.createBufferSource();
      src.buffer = this.noise;
      src.loop = true;
      const f = this.ctx.createBiquadFilter();
      f.type = "bandpass";
      f.frequency.value = 380;
      f.Q.value = 0.7;
      const g = this.ctx.createGain();
      g.gain.value = 0.018;
      src.connect(f);
      f.connect(g);
      g.connect(this.music);
      src.start();
    }
  }

  private scheduleBar(t0: number, beat: number, bar: number) {
    this.drum(t0);
    if (bar % 2 === 0) this.drum(t0 + beat * 4);
    this.drum(t0 + beat * 7.5);

    const luteA = [0, 3, 7, 5, 7, 10, 7, 3];
    const luteB = [5, 7, 10, 12, 10, 7, 5, 3];
    const luteC = [7, 5, 3, 0, 2, 3, 5, 7];
    const lute = bar % 4 === 0 ? luteA : bar % 4 === 2 ? luteB : luteC;
    lute.forEach((semi, i) => {
      this.pluck(t0 + i * beat, semi + 12, 0.7, 0.058);
    });

    const fluteA = [7, 10, 12, 10, 7, 5, 3, 0];
    const fluteB = [12, 10, 7, 5, 3, 5, 7, 10];
    if (bar % 2 === 1) {
      const flute = bar % 4 === 1 ? fluteA : fluteB;
      flute.forEach((semi, i) => {
        if (i % 2 === 1) return;
        this.flute(t0 + i * beat, semi, beat * 2.1, 0.032);
      });
    }
  }

  startScore() {
    if (!this.ctx || !this.music) return;
    this.startPads();
    this.scoreStart = this.ctx.currentTime + 0.2;
    this.lastBar = -1;
    const beat = 60 / 78;
    const barLen = beat * 8;
    const tick = () => {
      if (!this.ctx || !this.unlocked) return;
      const now = this.ctx.currentTime;
      const bar = Math.floor((now - this.scoreStart + 0.7) / barLen);
      if (bar > this.lastBar && bar >= 0) {
        this.lastBar = bar;
        this.scheduleBar(this.scoreStart + bar * barLen, beat, bar);
      }
      this.scoreTimer = window.setTimeout(tick, 200);
    };
    tick();
  }

  dispose() {
    if (this.scoreTimer != null) window.clearTimeout(this.scoreTimer);
    this.scoreTimer = null;
    this.unlocked = false;
    for (const o of this.drones) {
      try {
        o.stop();
      } catch {
        /* already stopped */
      }
    }
    this.drones = [];
    void this.ctx?.close();
    this.ctx = null;
  }
}
