import { useEffect, useRef, useState } from "react";
import type { Engine } from "@/game/engine";
import type { HudSnapshot } from "@/game/types";
import { Hud } from "./Hud";

const EMPTY: HudSnapshot = {
  food: 0,
  wood: 0,
  stone: 0,
  pop: 0,
  popCap: 0,
  age: 0,
  ages: ["Stone", "Bronze", "Iron", "Classical", "Medieval", "Renaissance"],
  time: 0,
  day: 1,
  clock: "06:42",
  period: "Dawn",
  weather: "Valley mist · 11°C",
  paused: false,
  speed: 1,
  ended: null,
  endReason: "",
  objective: "",
  placing: null,
  banner: null,
  selection: { name: "No selection", info: "", hp: 0, maxHp: 1, kind: "none" },
  canAge: false,
  ageCost: null,
  nextAge: "Bronze",
  tribes: [],
  trainOptions: [],
  buildOptions: [],
  fps: 0,
  started: false,
  muted: false,
  quality: "high",
};

export function GameApp() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<Engine | null>(null);
  const [hud, setHud] = useState<HudSnapshot>(EMPTY);
  const [ready, setReady] = useState(false);
  const [drag, setDrag] = useState<{ sx: number; sy: number; x: number; y: number } | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let cancelled = false;
    let engine: Engine | null = null;
    let dragTimer: number | null = null;

    import("@/game/engine").then(({ Engine }) => {
      if (cancelled || !canvasRef.current) return;
      engine = new Engine(canvasRef.current, (snap) => {
        setHud(snap);
      });
      engineRef.current = engine;
      setReady(true);
      dragTimer = window.setInterval(() => {
        setDrag(engine?.getDragRect() ?? null);
      }, 50);
    });

    return () => {
      cancelled = true;
      if (dragTimer) window.clearInterval(dragTimer);
      engine?.dispose();
      engineRef.current = null;
    };
  }, []);

  const begin = () => {
    engineRef.current?.begin();
  };

  return (
    <div className="relative h-dvh w-full overflow-hidden bg-ink">
      <canvas
        ref={canvasRef}
        className="absolute inset-0 size-full touch-none"
        style={{ display: "block", cursor: hud.placing ? "crosshair" : "default" }}
      />
      {drag && (
        <div
          className="pointer-events-none absolute z-20 border border-bronze-bright/80 bg-bronze/10"
          style={{
            left: Math.min(drag.sx, drag.x),
            top: Math.min(drag.sy, drag.y),
            width: Math.abs(drag.x - drag.sx),
            height: Math.abs(drag.y - drag.sy),
          }}
        />
      )}
      <Hud hud={hud} engine={engineRef.current} />
      {!hud.started && (
        <div className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-[radial-gradient(ellipse_at_70%_20%,#6a4a20_0%,#1a160e_55%,#0c0e0a_100%)]">
          <p className="font-display text-xs tracking-[0.35em] text-bronze uppercase">A valley at first light</p>
          <h1 className="mt-3 font-display text-6xl tracking-[0.28em] text-bronze-bright md:text-7xl">DAWN</h1>
          <p className="mt-1 font-display text-xl tracking-[0.42em] text-parchment-dim">OF EMPIRE</p>
          <p className="mt-6 max-w-md px-6 text-center text-sm leading-relaxed text-parchment-dim">
            Raise a Stone Age camp through Bronze, Iron, Classical and Medieval years into the Renaissance.
            One rival, Redcliff, shares this valley. A lute-and-flute score plays as you gather.
          </p>
          <button
            type="button"
            disabled={!ready}
            onClick={begin}
            className="mt-8 rounded-lg border border-bronze/50 bg-ink-soft px-8 py-3 font-display text-lg tracking-wide text-bronze-bright hover:bg-ink disabled:opacity-40"
          >
            {ready ? "Enter the valley" : "Painting the valley…"}
          </button>
          <p className="mt-6 text-[11px] text-parchment-dim/70">
            WASD pan · right-drag rotate · wheel zoom · left-click select
          </p>
        </div>
      )}
    </div>
  );
}
