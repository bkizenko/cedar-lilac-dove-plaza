import type { ReactNode } from "react";
import {
  Pause,
  Play,
  FastForward,
  Volume2,
  VolumeX,
  RotateCcw,
  Home,
  Wheat,
  TreePine,
  Mountain,
  Users,
  Sword,
  Hammer,
  Warehouse,
  Shield,
  Landmark,
  GraduationCap,
  Castle,
  Church,
  Store,
  Pickaxe,
  Axe,
  Eye,
  PawPrint,
  Sun,
} from "lucide-react";
import type { Engine } from "@/game/engine";
import type { HudSnapshot } from "@/game/types";
import { BUILDINGS } from "@/game/constants";

const BLD_ICON: Record<string, ReactNode> = {
  hut: <Home className="size-4" />,
  farm: <Wheat className="size-4" />,
  lumber: <Axe className="size-4" />,
  quarry: <Pickaxe className="size-4" />,
  warehouse: <Warehouse className="size-4" />,
  barracks: <Shield className="size-4" />,
  forge: <Hammer className="size-4" />,
  watchtower: <Eye className="size-4" />,
  temple: <Church className="size-4" />,
  market: <Store className="size-4" />,
  keep: <Castle className="size-4" />,
  stables: <PawPrint className="size-4" />,
  university: <GraduationCap className="size-4" />,
};

export function Hud({ hud, engine }: { hud: HudSnapshot; engine: Engine | null }) {
  if (!hud.started) return null;
  const sel = hud.selection;
  const hpPct = sel.maxHp > 0 ? Math.round((100 * sel.hp) / sel.maxHp) : 0;
  const weatherBits = hud.weather.split(" · ");
  const weatherName = weatherBits[0] || hud.weather;
  const weatherTemp = weatherBits[1] || "";

  return (
    <div className="hud-shell font-sans text-parchment">
      <div className="hud-res">
        <div className="hud-panel rounded-xl px-3 py-2.5 min-w-0">
          <ResRow icon={<Wheat className="size-3.5 text-blood" />} label="Berries" value={hud.food} />
          <ResRow icon={<TreePine className="size-3.5 text-ok" />} label="Logs" value={hud.wood} />
          <ResRow icon={<Mountain className="size-3.5 text-parchment-dim" />} label="Stone" value={hud.stone} />
          <ResRow icon={<Users className="size-3.5 text-dawn" />} label="People" value={`${hud.pop}/${hud.popCap}`} />
        </div>
        <div className="hud-panel rounded-xl px-3 py-2 flex items-start gap-2">
          <Hammer className="size-3.5 mt-0.5 text-bronze shrink-0" />
          <p className="text-xs leading-snug text-parchment-dim">{hud.objective}</p>
        </div>
      </div>

      <div className="hud-clock">
        <div className="hud-panel rounded-xl px-3 py-2.5 text-right">
          <div className="flex items-center justify-end gap-1.5">
            <Sun className="size-3.5 text-bronze-bright" />
            <div className="font-display text-lg leading-none tracking-wide text-bronze-bright">{hud.period}</div>
          </div>
          <div className="mt-1 text-xs text-parchment-dim tabular">
            {hud.clock} <span className="text-parchment-dim/70">(Day {hud.day})</span>
          </div>
          <div className="mt-0.5 flex items-center justify-end gap-2 text-[11px] text-parchment-dim/85">
            <span className="tabular">{weatherTemp}</span>
            <span>{weatherName}</span>
          </div>
          <div className="mt-2 font-display text-sm text-bronze">{hud.ages[hud.age]}</div>
          <div className="mt-2 flex justify-end gap-1">
            <IconBtn active={hud.paused} title="Pause" onClick={() => engine?.setPaused(!hud.paused)}>
              <Pause className="size-3.5" />
            </IconBtn>
            <IconBtn active={!hud.paused && hud.speed === 1} title="1×" onClick={() => engine?.setSpeed(1)}>
              <Play className="size-3.5" />
            </IconBtn>
            <IconBtn active={hud.speed === 2} title="2×" onClick={() => engine?.setSpeed(2)}>
              <FastForward className="size-3.5" />
            </IconBtn>
            <IconBtn active={hud.speed === 3} title="3×" onClick={() => engine?.setSpeed(3)}>
              <span className="text-[10px] font-semibold">3×</span>
            </IconBtn>
            <IconBtn title={hud.muted ? "Unmute" : "Mute"} onClick={() => engine?.toggleMute()}>
              {hud.muted ? <VolumeX className="size-3.5" /> : <Volume2 className="size-3.5" />}
            </IconBtn>
            <IconBtn title="Restart" onClick={() => engine?.restart()}>
              <RotateCcw className="size-3.5" />
            </IconBtn>
          </div>
        </div>
        <button
          type="button"
          disabled={!hud.nextAge || hud.paused || !!hud.ended}
          onClick={() => engine?.ageUp()}
          className="hud-panel w-full rounded-xl px-3 py-2 text-xs font-medium text-bronze-bright hover:bg-ink-soft disabled:opacity-40"
        >
          {hud.nextAge ? `Advance to ${hud.nextAge}` : "Renaissance"}
          {hud.ageCost ? (
            <span className="mt-0.5 block text-[10px] font-normal text-parchment-dim">
              {hud.ageCost.food ?? 0} berries · {hud.ageCost.wood ?? 0} logs · {hud.ageCost.stone ?? 0} stone
              {hud.ageCost.pop ? ` · ${hud.ageCost.pop} people` : ""}
            </span>
          ) : null}
        </button>
      </div>

      <div className="hud-banner">
        {hud.placing ? (
          <div className="rounded-lg border border-bronze/40 bg-ink/80 px-3 py-2 text-center text-xs text-bronze-bright shadow-lg">
            Click open grass to raise a {BUILDINGS[hud.placing].name}. Green ghost = clear. Right-click or Esc cancels.
          </div>
        ) : hud.banner ? (
          <div className="text-center font-display text-2xl tracking-[0.18em] text-bronze-bright drop-shadow-[0_2px_12px_rgba(0,0,0,0.7)] md:text-3xl">
            {hud.banner}
          </div>
        ) : null}
      </div>

      {hud.paused && !hud.ended && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
          <div className="font-display text-2xl tracking-[0.4em] text-bronze-bright">PAUSED</div>
        </div>
      )}

      <div className="hud-sel hud-panel rounded-xl p-3 w-full">
        <div className="font-display text-base text-bronze-bright">{sel.name}</div>
        <div className="text-xs text-parchment-dim mt-0.5">{sel.info}</div>
        {sel.carry ? <div className="text-[11px] text-dawn mt-1">{sel.carry}</div> : null}
        {sel.kind !== "none" ? (
          <>
            <div className="mt-2 text-[11px] text-parchment-dim">Condition {hpPct}%</div>
            <div className="mt-1 h-1.5 rounded-full bg-ink overflow-hidden border border-parchment/10">
              <div className="h-full rounded-full bg-ok" style={{ width: `${hpPct}%` }} />
            </div>
          </>
        ) : null}
      </div>

      <div className="hud-build hud-panel rounded-xl p-2 flex gap-1.5 overflow-x-auto">
        {hud.buildOptions.map((b, i) => {
          const locked = hud.age < b.age;
          const active = hud.placing === b.type;
          const unaffordable =
            hud.wood < (b.cost.wood || 0) || hud.stone < (b.cost.stone || 0) || hud.food < (b.cost.food || 0);
          return (
            <button
              key={b.type}
              type="button"
              disabled={locked || !!hud.ended}
              title={`${b.name} [${i + 1}]\n${b.hint}`}
              onClick={() => engine?.setPlacing(b.type)}
              className={`w-16 shrink-0 rounded-lg border px-1 py-1.5 text-center transition-colors ${
                active ? "border-bronze bg-bronze/20" : "border-parchment/15 bg-ink-soft hover:border-bronze/40"
              } ${locked || unaffordable ? "opacity-40" : ""}`}
            >
              <div className="mx-auto mb-1 flex size-8 items-center justify-center rounded-md bg-ink text-bronze">
                {BLD_ICON[b.type] || <Landmark className="size-4" />}
              </div>
              <div className="text-[10px] leading-tight text-parchment">{shortName(b.name)}</div>
              <div className="text-[9px] text-parchment-dim tabular">
                {b.cost.wood ? `L${b.cost.wood}` : ""} {b.cost.stone ? `S${b.cost.stone}` : ""}
              </div>
            </button>
          );
        })}
        {hud.trainOptions.length > 0 && (
          <div className="ml-1 flex gap-1.5 border-l border-parchment/15 pl-2">
            {hud.trainOptions.map((u) => {
              const locked = hud.age < u.age || hud.pop >= hud.popCap;
              return (
                <button
                  key={u.type}
                  type="button"
                  disabled={locked || hud.paused || !!hud.ended}
                  title={`Train ${u.name}`}
                  onClick={() => engine?.train(u.type)}
                  className="w-16 shrink-0 rounded-lg border border-parchment/15 bg-ink-soft px-1 py-1.5 text-center hover:border-bronze/40 disabled:opacity-40"
                >
                  <div className="mx-auto mb-1 flex size-8 items-center justify-center rounded-md bg-ink">
                    {u.type === "worker" ? (
                      <Users className="size-4 text-dawn" />
                    ) : (
                      <Sword className="size-4 text-bronze" />
                    )}
                  </div>
                  <div className="text-[10px] text-parchment">{u.name}</div>
                  <div className="text-[9px] text-parchment-dim">B{u.cost.food || 0}</div>
                </button>
              );
            })}
          </div>
        )}
      </div>

      <div className="hud-map hud-panel rounded-xl overflow-hidden">
        <Minimap hud={hud} engine={engine} />
        <div className="px-2 py-1.5 space-y-0.5">
          {hud.tribes.map((t) => (
            <div key={t.name} className="flex items-center gap-1.5 text-[10px] text-parchment-dim">
              <span className="size-1.5 rounded-full" style={{ background: t.alive ? t.color : "#4a4038" }} />
              <span className={t.alive ? "text-parchment" : "line-through opacity-50"}>{t.name}</span>
              <span className="ml-auto tabular">{t.alive ? hud.ages[t.age] : "Fallen"}</span>
            </div>
          ))}
        </div>
      </div>

      {hud.ended && (
        <div className="pointer-events-auto absolute inset-0 z-20 flex flex-col items-center justify-center gap-4 bg-ink/70">
          <h2 className="font-display text-5xl text-bronze-bright">{hud.ended === "win" ? "Victory" : "Defeat"}</h2>
          <p className="text-parchment max-w-md text-center px-6">{hud.endReason}</p>
          <button
            type="button"
            onClick={() => engine?.restart()}
            className="rounded-lg border border-bronze/40 bg-ink-soft px-5 py-2 text-sm text-bronze-bright hover:bg-ink"
          >
            Begin again
          </button>
        </div>
      )}
    </div>
  );
}

function ResRow({ icon, label, value }: { icon: ReactNode; label: string; value: string | number }) {
  return (
    <div className="flex items-center gap-2 text-sm leading-7">
      {icon}
      <span className="flex-1 text-parchment-dim text-[13px]">{label}</span>
      <span className="tabular min-w-10 text-right text-parchment">{value}</span>
    </div>
  );
}

function IconBtn({
  children,
  onClick,
  active,
  title,
}: {
  children: ReactNode;
  onClick: () => void;
  active?: boolean;
  title: string;
}) {
  return (
    <button
      type="button"
      title={title}
      onClick={onClick}
      className={`grid size-8 place-items-center rounded-md border text-parchment ${
        active ? "border-bronze text-bronze-bright" : "border-parchment/20 hover:border-bronze/40"
      }`}
    >
      {children}
    </button>
  );
}

function shortName(n: string) {
  if (n === "Lumber Camp") return "Lumber";
  if (n === "Watchtower") return "Tower";
  if (n === "University") return "Univ.";
  if (n === "Storehouse") return "Store";
  return n;
}

function Minimap({ hud, engine }: { hud: HudSnapshot; engine: Engine | null }) {
  return (
    <button
      type="button"
      aria-label="Minimap"
      className="block h-20 w-36 bg-moss/80 relative overflow-hidden"
      onClick={(e) => {
        const r = e.currentTarget.getBoundingClientRect();
        const nx = ((e.clientX - r.left) / r.width - 0.5) * 140;
        const nz = ((e.clientY - r.top) / r.height - 0.5) * 140;
        engine?.focusMinimap(nx, nz);
      }}
    >
      <Home className="absolute left-1/2 top-[62%] size-3 -translate-x-1/2 text-bronze-bright" />
      <span className="sr-only">Focus valley</span>
      <span className="absolute bottom-1 right-1 text-[9px] text-parchment/70 tabular">{hud.fps} fps</span>
    </button>
  );
}
