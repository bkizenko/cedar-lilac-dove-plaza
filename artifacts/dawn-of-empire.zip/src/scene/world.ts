import * as THREE from "three";
import { HALF, MAP, SEGS, TEAM_COLORS } from "@/game/constants";
import type { Game } from "@/game/sim";
import type { BldType, UnitType } from "@/game/types";
import {
  buildingGeos,
  bushGeo,
  fenceSegGeo,
  firepitGeo,
  flameGeo,
  goatGeo,
  grassGeo,
  makeMaterials,
  pineGeo,
  rockGeo,
  skyGeo,
  unitGeo,
  type MatKit,
} from "./meshes";

const UNIT_TYPES: UnitType[] = ["worker", "spearman", "archer", "swordsman", "cavalry"];
const BLD_TYPES: BldType[] = [
  "townhall",
  "hut",
  "farm",
  "lumber",
  "quarry",
  "warehouse",
  "barracks",
  "forge",
  "watchtower",
  "temple",
  "market",
  "keep",
  "stables",
  "university",
];

const _m = new THREE.Matrix4();
const _p = new THREE.Vector3();
const _q = new THREE.Quaternion();
const _s = new THREE.Vector3();
const _e = new THREE.Euler();
const _c = new THREE.Color();
const _ray = new THREE.Raycaster();
const _ndc = new THREE.Vector2();
const _ground = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
const _hit = new THREE.Vector3();

export class WorldView {
  renderer: THREE.WebGLRenderer;
  scene: THREE.Scene;
  camera: THREE.PerspectiveCamera;
  mats: MatKit;
  terrain: THREE.Mesh;
  water: THREE.Mesh;
  hemi: THREE.HemisphereLight;
  sun: THREE.DirectionalLight;
  fill: THREE.AmbientLight;
  hearth: THREE.PointLight;
  look = new THREE.Vector3(0, 1.2, 26);
  yaw = 1.12;
  pitch = 0.36;
  dist = 52;
  pan = { x: 0, z: 0 };
  treesTrunk!: THREE.InstancedMesh;
  treesLeaf!: THREE.InstancedMesh;
  rocks!: THREE.InstancedMesh;
  bushes!: THREE.InstancedMesh;
  grass: THREE.InstancedMesh | null = null;
  bldMeshes = new Map<BldType, { timber: THREE.InstancedMesh; roof: THREE.InstancedMesh; extra?: THREE.InstancedMesh }>();
  unitMeshes = new Map<UnitType, THREE.InstancedMesh>();
  rings!: THREE.InstancedMesh;
  ghost: THREE.Group;
  arrows: THREE.InstancedMesh;
  smoke: THREE.Points;
  smokeGeo: THREE.BufferGeometry;
  smokePos: Float32Array;
  flames!: THREE.InstancedMesh;
  pits!: THREE.InstancedMesh;
  floaters: THREE.Group;
  quality: "low" | "med" | "high" = "med";
  sky: THREE.Mesh;
  sunDisc: THREE.Mesh;
  sunGlow: THREE.Mesh;
  bounce: THREE.DirectionalLight;
  fence: THREE.InstancedMesh | null = null;
  goats: THREE.InstancedMesh | null = null;
  private tmpCam = new THREE.Vector3();
  private disposed = false;
  private treeCount = 0;
  private rockCount = 0;
  private bushCount = 0;

  constructor(canvas: HTMLCanvasElement) {
    const mobile = window.matchMedia("(max-width: 700px)").matches || navigator.maxTouchPoints > 1;
    this.quality = mobile ? "med" : "high";
    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      powerPreference: "high-performance",
      alpha: false,
      preserveDrawingBuffer: true,
    });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, mobile ? 1.5 : 2));
    this.renderer.setSize(canvas.clientWidth || 800, canvas.clientHeight || 600, false);
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.28;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color("#e2c9a0");
    this.scene.fog = new THREE.FogExp2("#e2c9a0", 0.0048);

    this.camera = new THREE.PerspectiveCamera(38, 1, 0.4, 420);
    this.mats = makeMaterials();

    this.hemi = new THREE.HemisphereLight("#ffe9c8", "#5a7a3c", 1.15);
    this.scene.add(this.hemi);
    this.fill = new THREE.AmbientLight("#f0e4c8", 0.38);
    this.scene.add(this.fill);
    this.sun = new THREE.DirectionalLight("#ffd08a", 2.15);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(this.quality === "high" ? 2048 : 1024, this.quality === "high" ? 2048 : 1024);
    this.sun.shadow.camera.near = 2;
    this.sun.shadow.camera.far = 160;
    this.sun.shadow.camera.left = -60;
    this.sun.shadow.camera.right = 60;
    this.sun.shadow.camera.top = 60;
    this.sun.shadow.camera.bottom = -60;
    this.sun.shadow.bias = -0.00045;
    this.sun.shadow.normalBias = 0.035;
    this.scene.add(this.sun);
    this.scene.add(this.sun.target);

    this.bounce = new THREE.DirectionalLight("#c8d8b8", 0.28);
    this.bounce.castShadow = false;
    this.scene.add(this.bounce);
    this.scene.add(this.bounce.target);

    this.hearth = new THREE.PointLight("#ff8a38", 2.1, 26, 1.5);
    this.hearth.castShadow = false;
    this.scene.add(this.hearth);

    this.sky = new THREE.Mesh(
      skyGeo(),
      new THREE.MeshBasicMaterial({ vertexColors: true, fog: false, depthWrite: false, side: THREE.BackSide }),
    );
    this.sky.renderOrder = -20;
    this.sky.frustumCulled = false;
    this.scene.add(this.sky);

    this.sunDisc = new THREE.Mesh(
      new THREE.CircleGeometry(3.2, 32),
      new THREE.MeshBasicMaterial({ color: "#fff6d2", fog: false, toneMapped: false, depthWrite: false, transparent: true }),
    );
    this.sunGlow = new THREE.Mesh(
      new THREE.CircleGeometry(9, 32),
      new THREE.MeshBasicMaterial({
        color: "#ffc878",
        fog: false,
        toneMapped: false,
        depthWrite: false,
        transparent: true,
        opacity: 0.18,
      }),
    );
    this.sunDisc.renderOrder = -19;
    this.sunGlow.renderOrder = -19;
    this.scene.add(this.sunDisc, this.sunGlow);

    this.terrain = new THREE.Mesh();
    this.water = new THREE.Mesh();
    this.ghost = new THREE.Group();
    this.scene.add(this.ghost);

    const arrowGeo = new THREE.ConeGeometry(0.08, 0.55, 5);
    arrowGeo.rotateX(Math.PI / 2);
    this.arrows = new THREE.InstancedMesh(arrowGeo, new THREE.MeshStandardMaterial({ color: "#3a2a14", roughness: 0.6 }), 40);
    this.arrows.count = 0;
    this.arrows.frustumCulled = false;
    this.scene.add(this.arrows);

    this.smokePos = new Float32Array(72 * 3);
    this.smokeGeo = new THREE.BufferGeometry();
    this.smokeGeo.setAttribute("position", new THREE.BufferAttribute(this.smokePos, 3));
    this.smoke = new THREE.Points(
      this.smokeGeo,
      new THREE.PointsMaterial({ color: "#e8e0d4", size: 0.55, transparent: true, opacity: 0.38, depthWrite: false }),
    );
    this.scene.add(this.smoke);

    this.floaters = new THREE.Group();
    this.scene.add(this.floaters);

    this.rings = new THREE.InstancedMesh(
      new THREE.RingGeometry(0.7, 0.88, 20),
      new THREE.MeshBasicMaterial({ color: "#e8c878", side: THREE.DoubleSide, transparent: true, opacity: 0.9 }),
      40,
    );
    this.rings.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.rings.count = 0;
    this.scene.add(this.rings);
  }

  resize() {
    const el = this.renderer.domElement;
    const w = el.clientWidth;
    const h = el.clientHeight;
    if (!w || !h) return;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  }

  applyQuality(q: "low" | "med" | "high") {
    this.quality = q;
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, q === "low" ? 1 : q === "med" ? 1.5 : 2));
    this.renderer.shadowMap.enabled = q !== "low";
    this.sun.castShadow = q !== "low";
    if (this.grass) this.grass.visible = q !== "low";
  }

  rebuild(game: Game) {
    this.disposeWorld();
    this.buildTerrain(game);
    this.buildNature(game);
    this.buildBuildings();
    this.buildUnits();
    this.buildHearths(game);
    this.buildCampDressing(game);
    this.look.set(0, this.sampleY(game, 0, 26) + 0.55, 26);
    this.updateCamera(0);
  }

  sampleY(game: Game, x: number, z: number) {
    return game.height(x, z);
  }

  private buildTerrain(game: Game) {
    const geo = new THREE.PlaneGeometry(MAP, MAP, SEGS, SEGS);
    geo.rotateX(-Math.PI / 2);
    const pos = geo.attributes.position;
    const colors: number[] = [];
    const col = new THREE.Color();
    const grass = new THREE.Color("#b6d86a");
    const grass2 = new THREE.Color("#c8e878");
    const dirt = new THREE.Color("#d2b07a");
    const sand = new THREE.Color("#ead9b4");
    const rock = new THREE.Color("#d0ccc4");
    const path = new THREE.Color("#c4a070");
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const z = pos.getZ(i);
      const h = game.height(x, z);
      pos.setY(i, h);
      const river = h < game.world.waterY + 0.32;
      const pathN = Math.abs(x - Math.sin(z * 0.08) * 1.6) < 1.7 && z < 30 && z > -10;
      const clearing = Math.hypot(x, z - 26) < 16;
      if (river) col.copy(sand);
      else if (h > 3.6) col.copy(rock);
      else if (pathN) col.copy(path);
      else if (h > 2.6) col.lerpColors(grass, dirt, 0.45);
      else if (clearing) col.lerpColors(grass2, dirt, 0.22);
      else col.lerpColors(grass, grass2, (Math.sin(x * 0.28) + Math.cos(z * 0.24)) * 0.25 + 0.5);
      colors.push(col.r, col.g, col.b);
    }
    geo.setAttribute("color", new THREE.Float32BufferAttribute(colors, 3));
    geo.computeVertexNormals();
    geo.computeBoundingBox();
    geo.computeBoundingSphere();
    this.terrain = new THREE.Mesh(geo, this.mats.ground);
    this.terrain.receiveShadow = true;
    this.terrain.name = "terrain";
    this.scene.add(this.terrain);

    const wgeo = new THREE.PlaneGeometry(MAP, MAP, 1, 1);
    wgeo.rotateX(-Math.PI / 2);
    this.water = new THREE.Mesh(
      wgeo,
      new THREE.MeshStandardMaterial({
        color: "#4a7e7c",
        roughness: 0.12,
        metalness: 0.22,
        transparent: true,
        opacity: 0.82,
        envMapIntensity: 0.9,
      }),
    );
    this.water.position.y = game.world.waterY;
    this.water.renderOrder = 1;
    this.scene.add(this.water);
  }

  private buildNature(game: Game) {
    const pine = pineGeo();
    const nTree = game.state.trees.length;
    this.treesTrunk = new THREE.InstancedMesh(pine.trunk, this.mats.bark, Math.max(nTree, 1));
    this.treesLeaf = new THREE.InstancedMesh(pine.canopy, this.mats.leaf.clone(), Math.max(nTree, 1));
    (this.treesLeaf.material as THREE.MeshStandardMaterial).color.set("#ffffff");
    this.treesLeaf.instanceColor = new THREE.InstancedBufferAttribute(new Float32Array(Math.max(nTree, 1) * 3), 3);
    this.treesTrunk.castShadow = this.quality !== "low";
    this.treesLeaf.castShadow = this.quality !== "low";
    this.treesTrunk.receiveShadow = true;
    this.treesLeaf.receiveShadow = true;
    this.treeCount = nTree;
    game.state.trees.forEach((t, i) => {
      _p.set(t.x, t.y, t.z);
      _e.set(0, i * 0.7, 0);
      _q.setFromEuler(_e);
      _s.set(t.scale, t.scale, t.scale);
      _m.compose(_p, _q, _s);
      this.treesTrunk.setMatrixAt(i, _m);
      this.treesLeaf.setMatrixAt(i, _m);
      _c.setHSL(0.31, 0.52, 0.42 + (i % 6) * 0.03);
      this.treesLeaf.setColorAt(i, _c);
    });
    this.treesTrunk.count = nTree;
    this.treesLeaf.count = nTree;
    this.scene.add(this.treesTrunk, this.treesLeaf);

    const nRock = game.state.stones.length;
    this.rocks = new THREE.InstancedMesh(rockGeo(), this.mats.rock, Math.max(nRock, 1));
    this.rocks.castShadow = true;
    this.rocks.receiveShadow = true;
    game.state.stones.forEach((s, i) => {
      _p.set(s.x, s.y, s.z);
      _e.set(0, i * 1.1, 0);
      _q.setFromEuler(_e);
      _s.set(s.scale, s.scale * 0.85, s.scale);
      _m.compose(_p, _q, _s);
      this.rocks.setMatrixAt(i, _m);
    });
    this.rocks.count = nRock;
    this.rockCount = nRock;
    this.scene.add(this.rocks);

    const nBush = game.state.forage.length;
    this.bushes = new THREE.InstancedMesh(bushGeo(), this.mats.berry, Math.max(nBush, 1));
    this.bushes.castShadow = true;
    game.state.forage.forEach((b, i) => {
      _p.set(b.x, b.y, b.z);
      _e.set(0, i, 0);
      _q.setFromEuler(_e);
      _s.set(b.scale, b.scale, b.scale);
      _m.compose(_p, _q, _s);
      this.bushes.setMatrixAt(i, _m);
    });
    this.bushes.count = nBush;
    this.bushCount = nBush;
    this.scene.add(this.bushes);

    const gCount = this.quality === "low" ? 280 : this.quality === "med" ? 700 : 1400;
    if (gCount) {
      const grassMat = this.mats.crop.clone();
      grassMat.color.set("#ffffff");
      this.grass = new THREE.InstancedMesh(grassGeo(), grassMat, gCount);
      this.grass.instanceColor = new THREE.InstancedBufferAttribute(new Float32Array(gCount * 3), 3);
      let gi = 0;
      for (let i = 0; i < gCount * 4 && gi < gCount; i++) {
        const nearCamp = i < gCount * 0.35;
        const x = nearCamp ? (Math.random() - 0.5) * 28 : (Math.random() - 0.5) * (MAP - 8);
        const z = nearCamp ? 26 + (Math.random() - 0.5) * 24 : (Math.random() - 0.5) * (MAP - 8);
        const y = game.height(x, z);
        if (y < game.world.waterY + 0.45) continue;
        _p.set(x, y, z);
        _e.set(0, Math.random() * 6, 0);
        _q.setFromEuler(_e);
        const sc = 0.85 + Math.random() * 1.1;
        _s.set(sc, sc * (0.9 + Math.random() * 0.4), sc);
        _m.compose(_p, _q, _s);
        this.grass.setMatrixAt(gi, _m);
        _c.setHSL(0.27 + Math.random() * 0.06, 0.55, 0.42 + Math.random() * 0.1);
        this.grass.setColorAt(gi, _c);
        gi++;
      }
      this.grass.count = gi;
      this.scene.add(this.grass);
    }
  }

  private buildBuildings() {
    const geos = buildingGeos();
    for (const type of BLD_TYPES) {
      const g = geos[type];
      const timber = new THREE.InstancedMesh(g.timber, this.mats.timber, 40);
      const roofMat = type === "keep" || type === "temple" || type === "university" ? this.mats.tile : this.mats.thatch;
      const roof = new THREE.InstancedMesh(g.roof, roofMat, 40);
      timber.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
      timber.instanceColor = new THREE.InstancedBufferAttribute(new Float32Array(40 * 3), 3);
      roof.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
      timber.castShadow = true;
      roof.castShadow = true;
      timber.receiveShadow = true;
      timber.count = 0;
      roof.count = 0;
      timber.frustumCulled = false;
      roof.frustumCulled = false;
      this.scene.add(timber, roof);
      let extra: THREE.InstancedMesh | undefined;
      if (g.extra) {
        extra = new THREE.InstancedMesh(g.extra, this.mats[g.extraMat || "stone"], 40);
        extra.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
        extra.castShadow = true;
        extra.count = 0;
        extra.frustumCulled = false;
        this.scene.add(extra);
      }
      this.bldMeshes.set(type, { timber, roof, extra });
    }
  }

  private buildUnits() {
    for (const t of UNIT_TYPES) {
      const geo = unitGeo(t);
      const mat = this.mats.hide.clone();
      mat.vertexColors = false;
      const mesh = new THREE.InstancedMesh(geo, mat, 80);
      mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
      mesh.instanceColor = new THREE.InstancedBufferAttribute(new Float32Array(80 * 3), 3);
      mesh.castShadow = this.quality !== "low";
      mesh.count = 0;
      mesh.frustumCulled = false;
      this.scene.add(mesh);
      this.unitMeshes.set(t, mesh);
    }
  }

  private buildHearths(game: Game) {
    const halls = game.state.buildings.filter((b) => b.type === "townhall" && b.hp > 0);
    this.pits = new THREE.InstancedMesh(firepitGeo(), this.mats.rock, 4);
    this.pits.castShadow = true;
    this.pits.receiveShadow = true;
    this.flames = new THREE.InstancedMesh(
      flameGeo(),
      new THREE.MeshBasicMaterial({ color: "#ffb040", transparent: true, opacity: 0.85, depthWrite: false }),
      8,
    );
    this.flames.frustumCulled = false;
    halls.forEach((h, i) => {
      _p.set(h.x + 1.6, h.y, h.z + 4.2);
      _q.identity();
      _s.set(1, 1, 1);
      _m.compose(_p, _q, _s);
      this.pits.setMatrixAt(i, _m);
    });
    this.pits.count = halls.length;
    this.flames.count = 0;
    this.scene.add(this.pits, this.flames);
    const home = halls.find((h) => h.team === 0);
    if (home) this.hearth.position.set(home.x + 1.6, home.y + 0.8, home.z + 4.2);
  }

  private buildCampDressing(game: Game) {
    const home = game.state.buildings.find((b) => b.type === "townhall" && b.team === 0);
    if (!home) return;
    const cx = home.x + 7.5;
    const cz = home.z + 2.5;
    const segs = 14;
    const radius = 5.2;
    this.fence = new THREE.InstancedMesh(fenceSegGeo(), this.mats.timber, segs);
    this.fence.castShadow = true;
    this.fence.receiveShadow = true;
    for (let i = 0; i < segs; i++) {
      const a = (i / segs) * Math.PI * 2;
      const x = cx + Math.cos(a) * radius;
      const z = cz + Math.sin(a) * radius;
      _p.set(x, game.height(x, z), z);
      _e.set(0, -a + Math.PI / 2, 0);
      _q.setFromEuler(_e);
      _s.set(1, 1, 1);
      _m.compose(_p, _q, _s);
      this.fence.setMatrixAt(i, _m);
    }
    this.fence.count = segs;
    this.scene.add(this.fence);

    this.goats = new THREE.InstancedMesh(goatGeo(), this.mats.hideDark, 4);
    this.goats.castShadow = true;
    const goatPos = [
      [cx + 1.2, cz + 0.6, 0.4],
      [cx - 1.4, cz - 0.8, 2.1],
      [cx + 0.2, cz - 1.6, -0.7],
      [cx - 0.6, cz + 1.4, 1.3],
    ];
    goatPos.forEach((g, i) => {
      const x = g[0],
        z = g[1];
      _p.set(x, game.height(x, z), z);
      _e.set(0, g[2], 0);
      _q.setFromEuler(_e);
      _s.set(1.15, 1.15, 1.15);
      _m.compose(_p, _q, _s);
      this.goats!.setMatrixAt(i, _m);
    });
    this.goats.count = 4;
    this.scene.add(this.goats);
  }

  updateCamera(dt: number) {
    const panSp = 22 * (this.dist / 38);
    if (this.pan.x || this.pan.z) {
      const fx = -Math.sin(this.yaw);
      const fz = -Math.cos(this.yaw);
      const rx = Math.cos(this.yaw);
      const rz = -Math.sin(this.yaw);
      this.look.x += (fx * this.pan.z + rx * this.pan.x) * panSp * dt;
      this.look.z += (fz * this.pan.z + rz * this.pan.x) * panSp * dt;
      this.look.x = THREE.MathUtils.clamp(this.look.x, -HALF + 8, HALF - 8);
      this.look.z = THREE.MathUtils.clamp(this.look.z, -HALF + 8, HALF - 8);
    }
    this.pitch = THREE.MathUtils.clamp(this.pitch, 0.28, 1.28);
    this.dist = THREE.MathUtils.clamp(this.dist, 12, 78);
    this.tmpCam.set(
      this.look.x + Math.sin(this.yaw) * Math.cos(this.pitch) * this.dist,
      this.look.y + Math.sin(this.pitch) * this.dist,
      this.look.z + Math.cos(this.yaw) * Math.cos(this.pitch) * this.dist,
    );
    this.camera.position.copy(this.tmpCam);
    this.camera.lookAt(this.look.x, this.look.y + 1.2, this.look.z);
  }

  groundAt(cx: number, cy: number): THREE.Vector3 | null {
    const el = this.renderer.domElement;
    const w = el.clientWidth || 1;
    const h = el.clientHeight || 1;
    _ndc.set((cx / w) * 2 - 1, -(cy / h) * 2 + 1);
    _ray.setFromCamera(_ndc, this.camera);
    const hits = _ray.intersectObject(this.terrain, false);
    if (hits[0]) return hits[0].point.clone();
    _ground.set(new THREE.Vector3(0, 1, 0), -this.look.y);
    if (_ray.ray.intersectPlane(_ground, _hit)) return _hit.clone();
    return null;
  }

  project(x: number, y: number, z: number) {
    _p.set(x, y, z).project(this.camera);
    const el = this.renderer.domElement;
    return { x: (_p.x * 0.5 + 0.5) * el.clientWidth, y: (-_p.y * 0.5 + 0.5) * el.clientHeight };
  }

  sync(game: Game, dt: number) {
    this.updateDay(game);
    this.syncNature(game);
    this.syncBuildings(game);
    this.syncUnits(game);
    this.syncGhost(game);
    this.syncArrows(game);
    this.syncSmoke(game, dt);
    this.water.position.y = game.world.waterY + Math.sin(game.state.time * 0.6) * 0.03;
  }

  private updateDay(game: Game) {
    const p = game.dayPhase();
    const hour = p * 24;
    const rise = 5.4;
    const set = 20.2;
    const t = (hour - rise) / (set - rise);
    const day = Math.max(0, Math.min(1, t));
    const elev = Math.sin(day * Math.PI);
    const dawn = Math.max(0, 1 - Math.abs(hour - 6.7) * 0.55);
    const dusk = Math.max(0, 1 - Math.abs(hour - 18.8) * 0.5);
    const night = hour < 5.2 || hour > 20.4 ? 1 : 0;
    const ang = ((hour - 6) / 12) * Math.PI;
    const dist = 90;
    this.sun.position.set(
      this.look.x + Math.cos(ang) * dist,
      4 + Math.max(2.5, elev * 52),
      this.look.z + Math.sin(ang) * dist * 0.55,
    );
    this.sun.target.position.copy(this.look);
    this.bounce.position.set(this.look.x - 20, 18, this.look.z + 12);
    this.bounce.target.position.copy(this.look);

    this.sun.intensity = 0.85 + elev * 1.55 + dawn * 0.9;
    this.sun.color.set(dawn > 0.2 || dusk > 0.25 ? "#ffc070" : night ? "#9aacd0" : "#fff1cc");
    this.hemi.intensity = 0.7 + elev * 0.55;
    this.hemi.color.set(night ? "#a8b8d8" : "#ffe9c8");
    this.fill.intensity = 0.28 + elev * 0.18;
    this.bounce.intensity = 0.18 + elev * 0.16;

    const fog = new THREE.Color().setStyle(
      night ? "#1c2434" : dawn > 0.25 ? "#e4c8a0" : dusk > 0.3 ? "#d8b090" : "#d5e0c8",
    );
    (this.scene.fog as THREE.FogExp2).color.copy(fog);
    this.scene.background = fog;
    (this.scene.fog as THREE.FogExp2).density = night ? 0.01 : dawn > 0.2 ? 0.0052 : 0.0042;
    this.renderer.toneMappingExposure = 1.08 + elev * 0.22 + dawn * 0.14;

    const sunDir = this.sun.position.clone().sub(this.look).normalize();
    this.sunDisc.position.copy(this.camera.position).add(sunDir.multiplyScalar(220));
    this.sunDisc.lookAt(this.camera.position);
    this.sunGlow.position.copy(this.sunDisc.position);
    this.sunGlow.lookAt(this.camera.position);
    const vis = night ? 0.12 : 1;
    (this.sunDisc.material as THREE.MeshBasicMaterial).opacity = vis;
    (this.sunGlow.material as THREE.MeshBasicMaterial).opacity = 0.16 * vis;
    this.sky.position.copy(this.camera.position);
  }

  private syncNature(game: Game) {
    if (game.state.trees.length !== this.treeCount) {
      this.treeCount = game.state.trees.length;
      game.state.trees.forEach((t, i) => {
        _p.set(t.x, t.y, t.z);
        _e.set(0, i * 0.7, 0);
        _q.setFromEuler(_e);
        _s.set(t.scale, t.scale, t.scale);
        _m.compose(_p, _q, _s);
        this.treesTrunk.setMatrixAt(i, _m);
        this.treesLeaf.setMatrixAt(i, _m);
      });
      this.treesTrunk.count = this.treeCount;
      this.treesLeaf.count = this.treeCount;
      this.treesTrunk.instanceMatrix.needsUpdate = true;
      this.treesLeaf.instanceMatrix.needsUpdate = true;
    }
    if (game.state.stones.length !== this.rockCount) {
      this.rockCount = game.state.stones.length;
      game.state.stones.forEach((s, i) => {
        _p.set(s.x, s.y, s.z);
        _e.set(0, i, 0);
        _q.setFromEuler(_e);
        _s.setScalar(s.scale);
        _m.compose(_p, _q, _s);
        this.rocks.setMatrixAt(i, _m);
      });
      this.rocks.count = this.rockCount;
      this.rocks.instanceMatrix.needsUpdate = true;
    }
    if (game.state.forage.length !== this.bushCount) {
      this.bushCount = game.state.forage.length;
      game.state.forage.forEach((b, i) => {
        _p.set(b.x, b.y, b.z);
        _e.set(0, i, 0);
        _q.setFromEuler(_e);
        _s.setScalar(b.scale);
        _m.compose(_p, _q, _s);
        this.bushes.setMatrixAt(i, _m);
      });
      this.bushes.count = this.bushCount;
      this.bushes.instanceMatrix.needsUpdate = true;
    }
  }

  private syncBuildings(game: Game) {
    const grouped = new Map<BldType, typeof game.state.buildings>();
    for (const type of BLD_TYPES) grouped.set(type, []);
    for (const b of game.state.buildings) {
      if (b.hp <= 0) continue;
      grouped.get(b.type)!.push(b);
    }
    for (const type of BLD_TYPES) {
      const list = grouped.get(type)!;
      const meshes = this.bldMeshes.get(type)!;
      list.forEach((b, i) => {
        _p.set(b.x, b.y, b.z);
        _q.identity();
        _s.set(1, 1, 1);
        _m.compose(_p, _q, _s);
        meshes.timber.setMatrixAt(i, _m);
        meshes.roof.setMatrixAt(i, _m);
        meshes.extra?.setMatrixAt(i, _m);
        const tint = TEAM_COLORS[b.team] || TEAM_COLORS[0];
        _c.set(tint);
        meshes.timber.setColorAt(i, _c);
      });
      meshes.timber.count = list.length;
      meshes.roof.count = list.length;
      if (meshes.extra) meshes.extra.count = list.length;
      meshes.timber.instanceMatrix.needsUpdate = true;
      meshes.roof.instanceMatrix.needsUpdate = true;
      if (meshes.extra) meshes.extra.instanceMatrix.needsUpdate = true;
      if (meshes.timber.instanceColor) meshes.timber.instanceColor.needsUpdate = true;
    }
  }

  private syncUnits(game: Game) {
    const grouped = new Map<UnitType, typeof game.state.units>();
    for (const t of UNIT_TYPES) grouped.set(t, []);
    for (const u of game.state.units) {
      if (u.hp > 0) grouped.get(u.type)!.push(u);
    }
    let ri = 0;
    for (const t of UNIT_TYPES) {
      const list = grouped.get(t)!;
      const mesh = this.unitMeshes.get(t)!;
      list.forEach((u, i) => {
        _p.set(u.x, u.y, u.z);
        _e.set(0, u.facing, 0);
        _q.setFromEuler(_e);
        _s.set(1.65, 1.65, 1.65);
        _m.compose(_p, _q, _s);
        mesh.setMatrixAt(i, _m);
        _c.set(TEAM_COLORS[u.team] || "#c4a060");
        mesh.setColorAt(i, _c);
        if (u.selected && ri < 40) {
          _p.set(u.x, u.y + 0.05, u.z);
          _e.set(-Math.PI / 2, 0, 0);
          _q.setFromEuler(_e);
          _s.set(u.r * 1.6, u.r * 1.6, 1);
          _m.compose(_p, _q, _s);
          this.rings.setMatrixAt(ri, _m);
          ri++;
        }
      });
      mesh.count = list.length;
      mesh.instanceMatrix.needsUpdate = true;
      if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
    }
    if (game.state.selBld && game.state.selBld.hp > 0 && ri < 40) {
      const b = game.state.selBld;
      _p.set(b.x, b.y + 0.06, b.z);
      _e.set(-Math.PI / 2, 0, 0);
      _q.setFromEuler(_e);
      _s.set(Math.max(b.w, b.d) * 0.55, Math.max(b.w, b.d) * 0.55, 1);
      _m.compose(_p, _q, _s);
      this.rings.setMatrixAt(ri, _m);
      ri++;
    }
    this.rings.count = ri;
    this.rings.instanceMatrix.needsUpdate = true;
  }

  private syncGhost(_game: Game) {
    /* ghost visibility is owned by Engine.updateGhost / setGhost */
  }

  setGhost(type: BldType | null, x: number, z: number, y: number, ok: boolean) {
    if (!type) {
      this.clearGhost();
      this.ghost.visible = false;
      return;
    }
    this.ghost.visible = true;
    this.ghost.position.set(x, y, z);
    const key = type + (ok ? "-ok" : "-bad");
    if (this.ghost.userData.key === key) return;
    this.clearGhost();
    this.ghost.userData.key = key;
    const meshes = this.bldMeshes.get(type);
    if (!meshes) return;
    const tint = ok ? "#6a8a48" : "#8a3a32";
    const mt = this.mats.timber.clone();
    mt.transparent = true;
    mt.opacity = 0.55;
    mt.depthWrite = false;
    mt.color.set(tint);
    mt.emissive.set(tint);
    mt.emissiveIntensity = 0.35;
    const mr = this.mats.thatch.clone();
    mr.transparent = true;
    mr.opacity = 0.5;
    mr.depthWrite = false;
    mr.color.set(ok ? "#8aaa58" : "#a05048");
    this.ghost.add(new THREE.Mesh(meshes.timber.geometry, mt));
    this.ghost.add(new THREE.Mesh(meshes.roof.geometry, mr));
    const pad = new THREE.Mesh(
      new THREE.PlaneGeometry(8, 8),
      new THREE.MeshBasicMaterial({
        color: tint,
        transparent: true,
        opacity: 0.35,
        side: THREE.DoubleSide,
        depthWrite: false,
      }),
    );
    pad.rotation.x = -Math.PI / 2;
    pad.position.y = 0.08;
    this.ghost.add(pad);
  }

  private clearGhost() {
    while (this.ghost.children.length) {
      const ch = this.ghost.children[0] as THREE.Mesh;
      this.ghost.remove(ch);
      const mat = ch.material;
      if (Array.isArray(mat)) mat.forEach((m) => m.dispose());
      else if (mat) (mat as THREE.Material).dispose();
    }
    this.ghost.userData.key = "";
  }

  private syncArrows(game: Game) {
    const ps = game.state.projectiles;
    ps.forEach((p, i) => {
      if (i >= 40) return;
      _p.set(p.x, p.y, p.z);
      const dx = p.tx - p.x,
        dy = p.ty - p.y,
        dz = p.tz - p.z;
      _e.set(0, Math.atan2(dx, dz), -Math.atan2(dy, Math.hypot(dx, dz)));
      _q.setFromEuler(_e);
      _s.set(1, 1, 1);
      _m.compose(_p, _q, _s);
      this.arrows.setMatrixAt(i, _m);
    });
    this.arrows.count = Math.min(ps.length, 40);
    this.arrows.instanceMatrix.needsUpdate = true;
  }

  private syncSmoke(game: Game, dt: number) {
    const halls = game.state.buildings.filter((b) => b.type === "townhall" && b.hp > 0);
    const n = 72;
    for (let i = 0; i < n; i++) {
      const h = halls[i % Math.max(halls.length, 1)];
      if (!h) {
        this.smokePos[i * 3 + 1] = -10;
        continue;
      }
      const t = game.state.time * 0.35 + i * 0.4;
      const k = (t % 3.2) / 3.2;
      this.smokePos[i * 3] = h.x + 1.6 + Math.sin(t) * 0.35;
      this.smokePos[i * 3 + 1] = h.y + 0.9 + k * 5.2;
      this.smokePos[i * 3 + 2] = h.z + 4.2 + Math.cos(t * 0.7) * 0.28;
    }
    this.smokeGeo.attributes.position.needsUpdate = true;
    if (this.flames) {
      let fi = 0;
      for (const h of halls) {
        for (let k = 0; k < 2 && fi < 8; k++, fi++) {
          const flicker = 0.85 + Math.sin(game.state.time * 11 + fi) * 0.18;
          _p.set(h.x + 1.6 + (k ? 0.08 : -0.05), h.y + 0.22, h.z + 4.2);
          _e.set(0, fi, 0);
          _q.setFromEuler(_e);
          _s.set(0.7 + k * 0.25, flicker * (1.1 - k * 0.25), 0.7 + k * 0.25);
          _m.compose(_p, _q, _s);
          this.flames.setMatrixAt(fi, _m);
        }
      }
      this.flames.count = fi;
      this.flames.instanceMatrix.needsUpdate = true;
    }
    const home = halls.find((h) => h.team === 0);
    if (home) {
      this.hearth.position.set(home.x + 1.6, home.y + 0.85, home.z + 4.2);
      this.hearth.intensity = 1.35 + Math.sin(game.state.time * 9) * 0.25;
    }
    void dt;
  }

  render() {
    this.renderer.render(this.scene, this.camera);
  }

  private disposeWorld() {
    const keep = new Set([
      this.ghost,
      this.arrows,
      this.smoke,
      this.floaters,
      this.rings,
      this.hemi,
      this.sun,
      this.sun.target,
      this.fill,
      this.hearth,
      this.sky,
      this.sunDisc,
      this.sunGlow,
      this.bounce,
      this.bounce.target,
    ]);
    const toRemove: THREE.Object3D[] = [];
    this.scene.traverse((o) => {
      if (o === this.scene || keep.has(o) || keep.has(o.parent as THREE.Object3D)) return;
      if (o.parent === this.scene && o !== this.hemi && o !== this.sun && o !== this.fill && o !== this.sun.target) {
        toRemove.push(o);
      }
    });
    for (const o of toRemove) {
      this.scene.remove(o);
      o.traverse((c) => {
        const m = c as THREE.Mesh;
        if (m.geometry) m.geometry.dispose();
      });
    }
    this.bldMeshes.clear();
    this.unitMeshes.clear();
  }

  dispose() {
    if (this.disposed) return;
    this.disposed = true;
    this.disposeWorld();
    this.renderer.dispose();
    for (const k of Object.values(this.mats)) {
      k.map?.dispose();
      k.bumpMap?.dispose();
      k.dispose();
    }
  }
}
